"use client";

import { useState, useCallback, useRef, useEffect } from "react";

export interface VoiceState {
  isListening: boolean;
  lastCommand: string;
  isSpeaking: boolean;
  isReady: boolean;
  recognitionSupported: boolean;
}

export function useVoiceEngine() {
  const [state, setState] = useState<VoiceState>({
    isListening: false,
    lastCommand: "",
    isSpeaking: false,
    isReady: false,
    recognitionSupported: false,
  });

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const voicesRef = useRef<any[]>([]);
  const isSetupRef = useRef(false);

  // Setup speech synthesis and recognition
  useEffect(() => {
    if (isSetupRef.current) return;
    isSetupRef.current = true;

    // Speech Synthesis setup
    synthRef.current = window.speechSynthesis;

    const loadVoices = () => {
      voicesRef.current = synthRef.current?.getVoices() || [];
    };

    loadVoices();
    if (synthRef.current) {
      synthRef.current.onvoiceschanged = loadVoices;
    }

    // Speech Recognition setup
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = "tr-TR";
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.maxAlternatives = 3;

      recognitionRef.current.onresult = (event: any) => {
        const results = event.results[0];
        let bestTranscript = results[0].transcript.trim().toLowerCase();

        // Normalize Turkish characters
        bestTranscript = bestTranscript
          .replace(/ı/g, "i")
          .replace(/ğ/g, "g")
          .replace(/ü/g, "u")
          .replace(/ş/g, "s")
          .replace(/ö/g, "o")
          .replace(/ç/g, "c");

        setState((prev) => ({
          ...prev,
          isListening: false,
          lastCommand: bestTranscript,
        }));
      };

      recognitionRef.current.onend = () => {
        setState((prev) => ({ ...prev, isListening: false }));
      };

      recognitionRef.current.onerror = () => {
        setState((prev) => ({ ...prev, isListening: false }));
      };

      setState((prev) => ({
        ...prev,
        recognitionSupported: true,
        isReady: true,
      }));
    } else {
      setState((prev) => ({ ...prev, recognitionSupported: false, isReady: true }));
    }

    return () => {
      recognitionRef.current?.stop();
      synthRef.current?.cancel();
    };
  }, []);

  // Get a unique voice for Turkish
  const getVoice = useCallback((): SpeechSynthesisVoice | null => {
    const voices = voicesRef.current;
    // Prefer a Turkish voice, especially female for a warmer tone
    const trVoices = voices.filter((v) => v.lang.startsWith("tr"));
    if (trVoices.length > 0) {
      return trVoices[0];
    }
    // Fallback to any available voice
    return voices[0] || null;
  }, []);

  // Speak text with unique settings
  const speak = useCallback(
    (text: string, options?: { rate?: number; pitch?: number; volume?: number; onEnd?: () => void }) => {
      if (!synthRef.current) return;

      synthRef.current.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "tr-TR";
      utterance.rate = options?.rate ?? 0.9;
      utterance.pitch = options?.pitch ?? 0.85;
      utterance.volume = options?.volume ?? 1;

      const voice = getVoice();
      if (voice) utterance.voice = voice;

      utterance.onstart = () => {
        setState((prev) => ({ ...prev, isSpeaking: true }));
      };

      utterance.onend = () => {
        setState((prev) => ({ ...prev, isSpeaking: false }));
        options?.onEnd?.();
      };

      utterance.onerror = () => {
        setState((prev) => ({ ...prev, isSpeaking: false }));
      };

      synthRef.current.speak(utterance);
    },
    [getVoice]
  );

  // Start listening for voice commands
  const startListening = useCallback(() => {
    if (recognitionRef.current && !state.isListening) {
      setState((prev) => ({ ...prev, isListening: true }));
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.error("Recognition start error:", e);
        setState((prev) => ({ ...prev, isListening: false }));
      }
    }
  }, [state.isListening]);

  // Stop listening
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setState((prev) => ({ ...prev, isListening: false }));
    }
  }, []);

  // Stop speaking
  const stopSpeaking = useCallback(() => {
    synthRef.current?.cancel();
    setState((prev) => ({ ...prev, isSpeaking: false }));
  }, []);

  return {
    ...state,
    speak,
    startListening,
    stopListening,
    stopSpeaking,
  };
}
