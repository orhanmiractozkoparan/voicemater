import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sokak Güvenliği Oyunu - Görme Engelliler İçin",
  description: "Görme engelliler için 3D sesli komutlu sokak haritası oyunu. On görev, kolaydan zora.",
  icons: { icon: "🧑‍🦯" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#070b14" />
      </head>
      <body className="bg-[#070b14] text-white antialiased min-h-screen">{children}</body>
    </html>
  );
}
