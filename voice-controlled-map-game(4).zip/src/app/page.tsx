import { GameClient } from "@/components/GameClient";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-900">
      <GameClient />
    </main>
  );
}
