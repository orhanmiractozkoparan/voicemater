"use client";

import { useState } from "react";
import { MapElement, ElementType, ELEMENT_TEMPLATES, generateId } from "@/lib/mapData";

interface Props {
  elements: MapElement[];
  onUpdate: (elements: MapElement[]) => void;
  onBack: () => void;
  onSpeak: (text: string, opts?: any) => void;
  onPlay: () => void;
  selectedId: string | null;
  onSelectOnMap: (id: string | null) => void;
  transformMode: "translate" | "rotate" | "scale";
  setTransformMode: (m: "translate" | "rotate" | "scale") => void;
  snapEnabled: boolean;
  setSnapEnabled: (b: boolean) => void;
  snapValue: number;
  setSnapValue: (n: number) => void;
  children?: React.ReactNode;
}

const TYPE_NAMES: Record<ElementType, string> = {
  building: "StaticMeshActor", road: "RoadActor", tree: "FoliageActor", car: "SplineMeshActor",
  trafficLight: "TrafficLightActor", crosswalk: "CrosswalkActor",
  streetLamp: "PointLightActor", busStop: "StaticMeshActor",
  bench: "StaticMeshActor", fountain: "StaticMeshActor", park: "LandscapeActor",
  flag: "TargetFlagActor", character: "CharacterActor",
};

const ROOF_OPTIONS = [
  { value: "flat", label: "Flat Roof" },
  { value: "pointed", label: "Pointed Roof" },
  { value: "dome", label: "Dome (Mosque)" },
];

export function UE5Editor({
  elements, onUpdate, onBack, onSpeak, onPlay,
  selectedId, onSelectOnMap, transformMode, setTransformMode,
  snapEnabled, setSnapEnabled, snapValue, setSnapValue,
  children
}: Props) {
  // --- UI Layout State (UE5 Panels) ---
  const [leftWidth, setLeftWidth] = useState(240);   // Outliner
  const [rightWidth, setRightWidth] = useState(300); // Details
  const [bottomHeight, setBottomHeight] = useState(200); // Content Browser
  
  const [searchOutliner, setSearchOutliner] = useState("");
  const [searchContent, setSearchContent] = useState("");
  const [selectedFolder, setSelectedFolder] = useState<"All" | ElementType>("All");
  const [hiddenIds, setHiddenIds] = useState<Set<string>>(new Set());

  // --- Resizing Handlers ---
  const handleLeftResize = (e: React.MouseEvent) => {
    const startX = e.clientX;
    const startWidth = leftWidth;
    const doDrag = (me: MouseEvent) => {
      setLeftWidth(Math.max(150, Math.min(400, startWidth + (me.clientX - startX))));
    };
    const stopDrag = () => {
      document.removeEventListener("mousemove", doDrag);
      document.removeEventListener("mouseup", stopDrag);
    };
    document.addEventListener("mousemove", doDrag);
    document.addEventListener("mouseup", stopDrag);
  };

  const handleRightResize = (e: React.MouseEvent) => {
    const startX = e.clientX;
    const startWidth = rightWidth;
    const doDrag = (me: MouseEvent) => {
      setRightWidth(Math.max(200, Math.min(500, startWidth - (me.clientX - startX))));
    };
    const stopDrag = () => {
      document.removeEventListener("mousemove", doDrag);
      document.removeEventListener("mouseup", stopDrag);
    };
    document.addEventListener("mousemove", doDrag);
    document.addEventListener("mouseup", stopDrag);
  };

  const handleBottomResize = (e: React.MouseEvent) => {
    const startY = e.clientY;
    const startHeight = bottomHeight;
    const doDrag = (me: MouseEvent) => {
      setBottomHeight(Math.max(100, Math.min(400, startHeight - (me.clientY - startY))));
    };
    const stopDrag = () => {
      document.removeEventListener("mousemove", doDrag);
      document.removeEventListener("mouseup", stopDrag);
    };
    document.addEventListener("mousemove", doDrag);
    document.addEventListener("mouseup", stopDrag);
  };

  // --- Logic ---
  const selectedEl = elements.find((e) => e.id === selectedId);

  const toggleVisibility = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHiddenIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSpawnAsset = (type: ElementType) => {
    const tpl = ELEMENT_TEMPLATES[type];
    const newEl: MapElement = {
      id: generateId(),
      type,
      label: `BP_${tpl.label}_${Math.floor(Math.random()*100)}`,
      description: `${tpl.label} öğesi`,
      x: Math.round((Math.random() * 10 - 5) * 2) / 2,
      y: 0,
      z: Math.round((Math.random() * 10 - 5) * 2) / 2,
      width: tpl.width, height: tpl.height, depth: tpl.depth,
      color: tpl.color, interactive: true,
      ...(type === "building" ? { floors: 1, roofType: "flat" as const } : {}),
      ...(type === "tree" ? { scale: 1 } : {}),
      ...(type === "car" ? { carColor: tpl.color, dirX: 1, speed: 3 } : {}),
    };
    onUpdate([...elements, newEl]);
    onSelectOnMap(newEl.id);
    onSpeak(`${tpl.label} dünyaya spawn edildi.`);
  };

  const handleDuplicate = () => {
    if (!selectedEl) return;
    const dup: MapElement = {
      ...selectedEl,
      id: generateId(),
      label: `${selectedEl.label}_Copy`,
      x: selectedEl.x + 2,
      z: selectedEl.z + 2,
    };
    onUpdate([...elements, dup]);
    onSelectOnMap(dup.id);
    onSpeak(`${selectedEl.label} kopyalandı.`);
  };

  const handleDelete = () => {
    if (!selectedId) return;
    if (selectedEl?.type === "character") return;
    onUpdate(elements.filter((e) => e.id !== selectedId));
    onSelectOnMap(null);
    onSpeak("Öğe silindi.");
  };

  const updateProp = (key: string, value: any) => {
    if (!selectedId) return;
    onUpdate(elements.map(e => e.id === selectedId ? { ...e, [key]: value } : e));
  };

  return (
    <div className="flex flex-col h-screen bg-[#151515] text-[#cccccc] font-sans text-xs overflow-hidden select-none">
      
      {/* ===================================================================
          TOOLBAR (Üst Çubuk)
          =================================================================== */}
      <div className="h-11 bg-[#1b1b1b] border-b border-[#121212] flex items-center justify-between px-3 flex-shrink-0">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded bg-black flex items-center justify-center font-black text-white text-xs border border-[#333]">U</div>
          <span className="font-bold text-[#f5f5f5] mr-4">Unreal Editor</span>
          
          <button onClick={onBack} className="px-2.5 py-1 hover:bg-[#2c2c2c] rounded text-slate-300">File</button>
          <button className="px-2.5 py-1 hover:bg-[#2c2c2c] rounded text-slate-300">Edit</button>
          <button className="px-2.5 py-1 hover:bg-[#2c2c2c] rounded text-slate-300">Window</button>
          <button className="px-2.5 py-1 hover:bg-[#2c2c2c] rounded text-slate-300">Tools</button>
          <button className="px-2.5 py-1 hover:bg-[#2c2c2c] rounded text-slate-300">Build</button>
        </div>

        {/* Play In Editor & Transform Buttons */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 bg-[#121212] rounded p-0.5 border border-[#2c2c2c]">
            <button
              onClick={() => setTransformMode("translate")}
              className={`p-1.5 rounded transition-all ${transformMode === "translate" ? "bg-sky-500 text-white" : "hover:bg-[#2a2a2a] text-slate-400"}`}
              title="Move (W)"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4M12 4l3 3m-3-3L9 7m3 13l3-3m-3 3l-3-3M20 12l-3 3m3-3l-3-3M4 12l3 3m-3-3l3-3" />
              </svg>
            </button>
            <button
              onClick={() => setTransformMode("rotate")}
              className={`p-1.5 rounded transition-all ${transformMode === "rotate" ? "bg-sky-500 text-white" : "hover:bg-[#2a2a2a] text-slate-400"}`}
              title="Rotate (E)"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.25 15.65m0 0H22m-1.25 0h.01" />
              </svg>
            </button>
            <button
              onClick={() => setTransformMode("scale")}
              className={`p-1.5 rounded transition-all ${transformMode === "scale" ? "bg-sky-500 text-white" : "hover:bg-[#2a2a2a] text-slate-400"}`}
              title="Scale (R)"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
              </svg>
            </button>
          </div>

          <div className="flex items-center gap-2 bg-[#121212] rounded p-0.5 border border-[#2c2c2c] text-[10px]">
            <label className="flex items-center gap-1.5 px-2 cursor-pointer text-slate-400">
              <input type="checkbox" checked={snapEnabled} onChange={(e) => setSnapEnabled(e.target.checked)} className="rounded accent-sky-500 bg-zinc-800 border-zinc-600" />
              Snap
            </label>
            {snapEnabled && (
              <select
                value={snapValue}
                onChange={(e) => setSnapValue(parseFloat(e.target.value))}
                className="bg-[#1b1b1b] border-l border-[#2c2c2c] px-1 py-0.5 text-sky-400 font-bold focus:outline-none"
              >
                <option value="0.1">0.1</option>
                <option value="0.5">0.5</option>
                <option value="1">1.0</option>
                <option value="2">2.0</option>
              </select>
            )}
          </div>

          <button
            onClick={onPlay}
            className="px-6 py-1 bg-[#1e3a2b] hover:bg-[#254a36] border border-[#2a4d3a] rounded font-bold text-green-400 flex items-center gap-1.5 transition-all shadow-md"
          >
            <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
            PLAY (PIE)
          </button>
        </div>

        {/* Perf */}
        <div className="flex items-center gap-4 text-[10px] text-slate-500">
          <span>Mem: 485MB</span>
          <span className="text-green-500 font-bold">Oyun Hazır</span>
        </div>
      </div>

      {/* ===================================================================
          ANA ÇALIŞMA ALANI (MAIN WORKSPACE)
          =================================================================== */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* === SOL PANEL: WORLD OUTLINER === */}
        <div className="flex flex-col bg-[#1b1b1b] border-r border-[#121212] flex-shrink-0" style={{ width: leftWidth }}>
          <div className="h-8 bg-[#222222] border-b border-[#121212] flex items-center px-3 font-bold text-[#888888] tracking-wider uppercase text-[10px] justify-between">
            <span>Outliner</span>
            <span className="text-[9px] lowercase font-normal text-slate-500">{elements.length} items</span>
          </div>

          <div className="p-1.5 border-b border-[#121212] bg-[#151515]">
            <input
              type="text"
              placeholder="Search Actor..."
              value={searchOutliner}
              onChange={(e) => setSearchOutliner(e.target.value)}
              className="w-full px-2 py-1 bg-[#1c1c1c] border border-[#2c2c2c] rounded text-white text-[11px] placeholder-[#555] focus:outline-none focus:border-sky-500"
            />
          </div>

          {/* Outliner List */}
          <div className="flex-1 overflow-y-auto bg-[#1c1c1c] font-mono text-[11px]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#2a2a2a] text-[#888] border-b border-[#121212] text-[9px]">
                  <th className="py-1 px-2 font-normal w-6"></th>
                  <th className="py-1 px-2 font-normal">Actor Name</th>
                  <th className="py-1 px-2 font-normal w-24">Type</th>
                </tr>
              </thead>
              <tbody>
                {elements
                  .filter((el) => el.label.toLowerCase().includes(searchOutliner.toLowerCase()))
                  .map((el) => {
                    const isSelected = selectedId === el.id;
                    const isHidden = hiddenIds.has(el.id);
                    return (
                      <tr
                        key={el.id}
                        onClick={() => {
                          if (!isHidden) {
                            onSelectOnMap(el.id);
                            onSpeak(`${el.label} seçildi.`);
                          }
                        }}
                        className={`border-b border-[#151515] cursor-pointer group ${
                          isHidden ? "opacity-30" : isSelected ? "bg-sky-900/40 text-sky-400" : "hover:bg-[#252525] text-slate-300"
                        }`}
                      >
                        <td className="py-1 px-2 text-center" onClick={(e) => toggleVisibility(el.id, e)}>
                          <span className="hover:text-white transition-all text-[10px]">
                            {isHidden ? "❌" : "👁️"}
                          </span>
                        </td>
                        <td className="py-1 px-2 truncate font-semibold">
                          {ELEMENT_TEMPLATES[el.type].icon} {el.label}
                        </td>
                        <td className="py-1 px-2 truncate text-slate-500 text-[10px]">
                          {TYPE_NAMES[el.type]}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>

        {/* LEFT RESIZE HANDLE */}
        <div onMouseDown={handleLeftResize} className="w-1 bg-[#121212] hover:bg-sky-500 cursor-col-resize flex-shrink-0 transition-colors duration-200 z-10" />

        {/* === ORTA ALAN: VIEWPORT + CONTENT BROWSER === */}
        <div className="flex-1 flex flex-col relative bg-[#151515] overflow-hidden">
          {/* VIEWPORT PANEL */}
          <div className="flex-1 bg-black relative" id="ue5-viewport-parent">
            {children}
            <div className="absolute top-3 right-3 flex items-center gap-2 bg-[#1b1b1b]/60 border border-[#333]/40 p-1 rounded z-20">
              <button className="px-2 py-0.5 bg-[#2c2c2c] text-slate-300 text-[10px] rounded">Lit</button>
              <button className="px-2 py-0.5 hover:bg-[#2c2c2c] text-slate-400 text-[10px] rounded">Perspective</button>
              <button className="px-2 py-0.5 hover:bg-[#2c2c2c] text-slate-400 text-[10px] rounded">Show</button>
            </div>
          </div>

          {/* BOTTOM RESIZE HANDLE */}
          <div onMouseDown={handleBottomResize} className="h-1 bg-[#121212] hover:bg-sky-500 cursor-row-resize flex-shrink-0 transition-colors duration-200 z-10" />

          {/* === ALT PANEL: CONTENT BROWSER === */}
          <div className="bg-[#1b1b1b] border-t border-[#121212] flex flex-col flex-shrink-0" style={{ height: bottomHeight }}>
            <div className="h-8 bg-[#222222] border-b border-[#121212] flex items-center px-3 font-bold text-[#888888] tracking-wider uppercase text-[10px] justify-between">
              <div className="flex items-center gap-4">
                <span className="text-white">Content Drawer</span>
                <div className="flex bg-[#121212] rounded overflow-hidden border border-[#333]">
                  <button onClick={() => setSelectedFolder("All")} className={`px-2 py-0.5 ${selectedFolder === "All" ? "bg-sky-500 text-white" : "hover:bg-[#252525]"}`}>All</button>
                  <button onClick={() => setSelectedFolder("building")} className={`px-2 py-0.5 ${selectedFolder === "building" ? "bg-sky-500 text-white" : "hover:bg-[#252525]"}`}>StaticMesh</button>
                  <button onClick={() => setSelectedFolder("road")} className={`px-2 py-0.5 ${selectedFolder === "road" ? "bg-sky-500 text-white" : "hover:bg-[#252525]"}`}>Road</button>
                  <button onClick={() => setSelectedFolder("tree")} className={`px-2 py-0.5 ${selectedFolder === "tree" ? "bg-sky-500 text-white" : "hover:bg-[#252525]"}`}>Foliage</button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Search Assets..."
                  value={searchContent}
                  onChange={(e) => setSearchContent(e.target.value)}
                  className="px-2 py-0.5 bg-[#121212] border border-[#333] rounded text-white text-[10px] focus:outline-none focus:border-sky-500 w-36"
                />
                <span className="text-[9px] font-normal text-slate-500">Path: Content/AllProps/</span>
              </div>
            </div>

            <div className="flex-1 flex overflow-hidden bg-[#1c1c1c]">
              {/* Klasör Ağacı */}
              <div className="w-36 border-r border-[#121212] bg-[#181818] p-2 text-[10px] font-mono space-y-1 overflow-y-auto">
                <div className="text-slate-500 mb-1">🗂️ Content</div>
                <div className="pl-3 text-sky-400 cursor-pointer font-bold">📂 AllProps</div>
                <div className="pl-6 text-slate-400 hover:text-white cursor-pointer">📁 Blueprints</div>
                <div className="pl-6 text-slate-400 hover:text-white cursor-pointer">📁 StaticMeshes</div>
                <div className="pl-6 text-slate-400 hover:text-white cursor-pointer">📁 Materials</div>
              </div>

              {/* Asset Grid */}
              <div className="flex-1 overflow-y-auto p-2 grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                {Object.entries(ELEMENT_TEMPLATES)
                  .filter(([type]) => type !== "character")
                  .filter(([type]) => selectedFolder === "All" || selectedFolder === type)
                  .filter(([, tpl]) => tpl.label.toLowerCase().includes(searchContent.toLowerCase()))
                  .map(([type, tpl]) => (
                    <div
                      key={type}
                      onDoubleClick={() => handleSpawnAsset(type as ElementType)}
                      onClick={() => onSpeak(`${tpl.label} varlığı. Sahneye eklemek için çift tıklayın.`)}
                      className="glass-light border border-[#2c2c2c] hover:border-sky-500 rounded-lg p-1.5 text-center cursor-pointer flex flex-col items-center justify-between hover:bg-[#252525] group"
                    >
                      <div className="text-2xl mb-1 group-hover:scale-110 transition-transform">{tpl.icon}</div>
                      <div className="w-full">
                        <div className="text-[9px] font-semibold text-white truncate w-full">BP_{tpl.label}</div>
                        <div className="text-[8px] text-slate-500 uppercase font-bold tracking-wider mt-0.5">{TYPE_NAMES[type as ElementType]}</div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT RESIZE HANDLE */}
        <div onMouseDown={handleRightResize} className="w-1 bg-[#121212] hover:bg-sky-500 cursor-col-resize flex-shrink-0 transition-colors duration-200 z-10" />

        {/* === SAĞ PANEL: DETAILS (ÖZELLİKLER) === */}
        <div className="flex flex-col bg-[#1b1b1b] border-l border-[#121212] flex-shrink-0 overflow-y-auto" style={{ width: rightWidth }}>
          <div className="h-8 bg-[#222222] border-b border-[#121212] flex items-center px-3 font-bold text-[#888888] tracking-wider uppercase text-[10px] justify-between">
            <span>Details</span>
            <span className="text-[9px] uppercase font-bold text-sky-500">{selectedEl ? "SELECTED" : "NONE"}</span>
          </div>

          {selectedEl ? (
            <div className="flex-1 flex flex-col p-3 space-y-4 text-[11px] bg-[#1c1c1c]">
              {/* Actor Tag */}
              <div className="flex items-center gap-3 border-b border-[#333] pb-3">
                <div className="w-8 h-8 rounded bg-[#121212] border border-[#333] flex items-center justify-center text-xl">
                  {ELEMENT_TEMPLATES[selectedEl.type].icon}
                </div>
                <div className="flex-1 min-w-0">
                  <input
                    type="text"
                    value={selectedEl.label}
                    onChange={(e) => updateProp("label", e.target.value)}
                    className="w-full bg-[#121212] border border-[#333] px-2 py-0.5 text-white rounded font-bold focus:outline-none focus:border-sky-500 text-[11px]"
                  />
                  <div className="text-[8px] text-slate-500 mt-0.5 font-mono">{selectedEl.id}</div>
                </div>
              </div>

              {/* TRANSFORM */}
              <div className="space-y-2 border-b border-[#333] pb-3">
                <div className="text-[9px] font-bold text-[#888] uppercase tracking-wider mb-2">Transform</div>
                
                {/* Location */}
                <div className="flex items-center gap-2">
                  <span className="w-14 text-slate-400 text-[10px]">Location</span>
                  <div className="flex-1 grid grid-cols-3 gap-1">
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-red-600 text-white px-1 py-0.5 text-[8px] font-bold">X</span>
                      <input type="number" step="0.5" value={selectedEl.x} onChange={(e) => updateProp("x", parseFloat(e.target.value)||0)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-green-600 text-white px-1 py-0.5 text-[8px] font-bold">Y</span>
                      <input type="number" step="0.1" value={selectedEl.y || 0} onChange={(e) => updateProp("y", parseFloat(e.target.value)||0)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-blue-600 text-white px-1 py-0.5 text-[8px] font-bold">Z</span>
                      <input type="number" step="0.5" value={selectedEl.z} onChange={(e) => updateProp("z", parseFloat(e.target.value)||0)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                  </div>
                </div>

                {/* Rotation */}
                <div className="flex items-center gap-2">
                  <span className="w-14 text-slate-400 text-[10px]">Rotation</span>
                  <div className="flex-1 grid grid-cols-3 gap-1">
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden opacity-40">
                      <span className="bg-red-600 text-white px-1 py-0.5 text-[8px] font-bold">X</span>
                      <input type="number" disabled value={0} className="bg-transparent w-full px-1 text-slate-500 focus:outline-none text-[10px] text-center" />
                    </div>
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-green-600 text-white px-1 py-0.5 text-[8px] font-bold">Y</span>
                      <input type="number" step="0.1" value={selectedEl.roadRotY ? (selectedEl.roadRotY * 180 / Math.PI) : 0} onChange={(e) => updateProp("roadRotY", (parseFloat(e.target.value)||0) * Math.PI / 180)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden opacity-40">
                      <span className="bg-blue-600 text-white px-1 py-0.5 text-[8px] font-bold">Z</span>
                      <input type="number" disabled value={0} className="bg-transparent w-full px-1 text-slate-500 focus:outline-none text-[10px] text-center" />
                    </div>
                  </div>
                </div>

                {/* Scale */}
                <div className="flex items-center gap-2">
                  <span className="w-14 text-slate-400 text-[10px]">Scale</span>
                  <div className="flex-1 grid grid-cols-3 gap-1">
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-red-600 text-white px-1 py-0.5 text-[8px] font-bold">X</span>
                      <input type="number" step="0.1" value={selectedEl.scale || 1} onChange={(e) => updateProp("scale", parseFloat(e.target.value)||1)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-green-600 text-white px-1 py-0.5 text-[8px] font-bold">Y</span>
                      <input type="number" step="0.1" value={selectedEl.scale || 1} onChange={(e) => updateProp("scale", parseFloat(e.target.value)||1)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                    <div className="flex bg-[#121212] border border-[#2c2c2c] rounded overflow-hidden">
                      <span className="bg-blue-600 text-white px-1 py-0.5 text-[8px] font-bold">Z</span>
                      <input type="number" step="0.1" value={selectedEl.scale || 1} onChange={(e) => updateProp("scale", parseFloat(e.target.value)||1)} className="bg-transparent w-full px-1 text-white focus:outline-none text-[10px] text-center" />
                    </div>
                  </div>
                </div>
              </div>

              {/* MATERIAL & COLOR */}
              <div className="space-y-2 border-b border-[#333] pb-3">
                <div className="text-[9px] font-bold text-[#888] uppercase tracking-wider mb-1">Material / Color</div>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={selectedEl.color}
                    onChange={(e) => updateProp("color", e.target.value)}
                    className="w-10 h-7 rounded bg-transparent border-0 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={selectedEl.color}
                    onChange={(e) => updateProp("color", e.target.value)}
                    className="flex-1 bg-[#121212] border border-[#333] px-2 py-1 text-white rounded font-mono focus:outline-none focus:border-sky-500 text-[10px]"
                  />
                </div>
              </div>

              {/* SPECIFIC SETTINGS */}
              {selectedEl.type === "building" && (
                <div className="space-y-2 border-b border-[#333] pb-3">
                  <div className="text-[9px] font-bold text-[#888] uppercase tracking-wider mb-1">Static Mesh Settings</div>
                  <div className="flex items-center gap-2">
                    <span className="w-14 text-slate-400">Floors</span>
                    <input type="number" min="1" max="10" value={selectedEl.floors || 1} onChange={(e) => updateProp("floors", Math.max(1, parseInt(e.target.value)||1))} className="bg-[#121212] border border-[#333] px-2 py-0.5 text-white rounded w-full" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-14 text-slate-400">Roof</span>
                    <select value={selectedEl.roofType || "flat"} onChange={(e) => updateProp("roofType", e.target.value)} className="bg-[#121212] border border-[#333] px-2 py-0.5 text-white rounded w-full">
                      {ROOF_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                  </div>
                </div>
              )}

              {selectedEl.type === "car" && (
                <div className="space-y-2 border-b border-[#333] pb-3">
                  <div className="text-[9px] font-bold text-[#888] uppercase tracking-wider mb-1">Movement</div>
                  <div className="flex items-center gap-2">
                    <span className="w-14 text-slate-400">Dir</span>
                    <select value={selectedEl.dirX || 1} onChange={(e) => updateProp("dirX", parseInt(e.target.value))} className="bg-[#121212] border border-[#333] px-2 py-0.5 text-white rounded w-full">
                      <option value="1">Forward (→)</option>
                      <option value="-1">Backward (←)</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-14 text-slate-400">Speed</span>
                    <input type="number" step="0.5" value={selectedEl.speed || 3} onChange={(e) => updateProp("speed", parseFloat(e.target.value)||3)} className="bg-[#121212] border border-[#333] px-2 py-0.5 text-white rounded w-full" />
                  </div>
                </div>
              )}

              {/* ACCESSIBILITY */}
              <div className="space-y-2 border-b border-[#333] pb-3 flex-1">
                <div className="text-[9px] font-bold text-[#888] uppercase tracking-wider mb-1">Accessibility Tags</div>
                <label className="flex items-center gap-2 cursor-pointer py-1">
                  <input type="checkbox" checked={selectedEl.interactive || false} onChange={(e) => updateProp("interactive", e.target.checked)} className="rounded accent-sky-500" />
                  <span className="text-slate-300">Screen Reader Active</span>
                </label>
                <div className="flex flex-col gap-1">
                  <span className="text-[8px] text-slate-500 font-bold uppercase">TTS Prompt</span>
                  <textarea value={selectedEl.description} onChange={(e) => updateProp("description", e.target.value)} rows={3} placeholder="Açıklama girin..." className="w-full bg-[#121212] border border-[#333] px-2 py-1 text-white rounded resize-none focus:outline-none" />
                </div>
                {selectedEl.type === "building" && (
                  <div className="flex items-center gap-2 mt-1">
                    <span className="w-14 text-slate-400">Mission</span>
                    <select value={selectedEl.taskId || ""} onChange={(e) => updateProp("taskId", e.target.value ? parseInt(e.target.value) : undefined)} className="bg-[#121212] border border-[#333] px-2 py-0.5 text-white rounded w-full">
                      <option value="">None</option>
                      {Array.from({ length: 10 }, (_, i) => <option key={i + 1} value={i + 1}>Task {i + 1}</option>)}
                    </select>
                  </div>
                )}
              </div>

              {/* ACTIONS */}
              <div className="flex gap-2 pt-1 flex-shrink-0">
                <button onClick={handleDuplicate} className="flex-1 py-1 bg-[#2a2a2a] border border-[#444] rounded font-semibold text-slate-200">Duplicate</button>
                {selectedEl.type !== "character" && (
                  <button onClick={handleDelete} className="flex-1 py-1 bg-[#4c1d1d] border border-red-500/20 rounded font-semibold text-red-400">Delete Actor</button>
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-[#1c1c1c] text-slate-500 text-center p-4">
              <div>
                <svg className="w-6 h-6 mx-auto mb-1 text-slate-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <p className="font-bold text-[10px]">No Actor Selected</p>
                <p className="text-[8px] text-slate-600 mt-0.5">Select an element to edit details.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
