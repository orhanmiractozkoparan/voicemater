"use client";

import { useState } from "react";
import { MapElement, ElementType, ELEMENT_TEMPLATES, generateId } from "@/lib/mapData";

interface Props {
  elements: MapElement[];
  onUpdate: (elements: MapElement[]) => void;
  onBack: () => void;
  onSpeak: (text: string, opts?: any) => void;
  onSelectOnMap: (id: string | null) => void;
  selectedId: string | null;
}

const TYPE_LIST: ElementType[] = [
  "building", "road", "tree", "car", "trafficLight",
  "crosswalk", "streetLamp", "busStop", "bench",
  "fountain", "park", "flag",
];

const TYPE_NAMES: Record<ElementType, string> = {
  building: "Bina", road: "Yol", tree: "Ağaç", car: "Araba",
  trafficLight: "Trafik Işığı", crosswalk: "Yaya Geçidi",
  streetLamp: "Sokak Lambası", busStop: "Otobüs Durağı",
  bench: "Bank", fountain: "Çeşme", park: "Park Alanı",
  flag: "Bayrak", character: "Karakter",
};

const ROOF_OPTIONS: { value: string; label: string }[] = [
  { value: "flat", label: "Düz Çatı" },
  { value: "pointed", label: "Sivri Çatı" },
  { value: "dome", label: "Kubbe" },
];

export function MapEditor({ elements, onUpdate, onBack, onSpeak, onSelectOnMap, selectedId }: Props) {
  const [filterType, setFilterType] = useState<ElementType | "all">("all");
  const [showAddPanel, setShowAddPanel] = useState(false);
  const [addType, setAddType] = useState<ElementType>("building");

  const selectedEl = elements.find((e) => e.id === selectedId);

  const filtered = filterType === "all" ? elements : elements.filter((e) => e.type === filterType);

  // ---- ADD ----
  const handleAdd = () => {
    const tpl = ELEMENT_TEMPLATES[addType];
    const newEl: MapElement = {
      id: generateId(),
      type: addType,
      label: tpl.label,
      description: "",
      x: 0, y: 0, z: 0,
      width: tpl.width,
      height: tpl.height,
      depth: tpl.depth,
      color: tpl.color,
      interactive: false,
      ...(addType === "building" ? { floors: 1, roofType: "flat" as const } : {}),
      ...(addType === "tree" ? { scale: 1 } : {}),
      ...(addType === "car" ? { carColor: tpl.color, dirX: 1, speed: 3 } : {}),
    };
    onUpdate([...elements, newEl]);
    onSelectOnMap(newEl.id);
    setShowAddPanel(false);
    onSpeak(`${tpl.label} eklendi. Konumunu ayarlayın.`);
  };

  // ---- UPDATE PROPERTY ----
  const updateProp = (id: string, key: string, value: any) => {
    onUpdate(
      elements.map((e) =>
        e.id === id ? { ...e, [key]: value } : e
      )
    );
  };

  // ---- DELETE ----
  const handleDelete = (id: string) => {
    const el = elements.find((e) => e.id === id);
    if (el?.type === "character") {
      onSpeak("Karakter silinemez!");
      return;
    }
    onUpdate(elements.filter((e) => e.id !== id));
    if (selectedId === id) onSelectOnMap(null);
    onSpeak(`${el?.label || "Öğe"} silindi.`);
  };

  // ---- DUPLICATE ----
  const handleDuplicate = (id: string) => {
    const el = elements.find((e) => e.id === id);
    if (!el) return;
    const dup: MapElement = { ...el, id: generateId(), label: el.label + " Kopya", x: el.x + 3, z: el.z + 3 };
    onUpdate([...elements, dup]);
    onSelectOnMap(dup.id);
    onSpeak(`${el.label} kopyalandı.`);
  };

  // ---- COLOR PRESETS ----
  const colorPresets = [
    "#7c3aed", "#2563eb", "#dc2626", "#059669", "#0d9488",
    "#e11d48", "#ea580c", "#b45309", "#d97706", "#9333ea",
    "#0891b2", "#333333", "#22c55e", "#6366f1", "#fbbf24",
    "#ef4444", "#38bdf8", "#ffffff",
  ];

  return (
    <div className="flex h-screen bg-[#070b14] overflow-hidden">
      {/* ====== LEFT SIDEBAR — ELEMENT LIST ====== */}
      <div className="w-80 flex-shrink-0 border-r border-slate-800 bg-[#0c1222] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-2 mb-3">
            <button onClick={onBack} className="voice-btn px-3 py-1.5 glass rounded-lg text-sm text-white hover:bg-white/10">← Geri</button>
            <h2 className="text-lg font-black shimmer-text">🛠️ Harita Editörü</h2>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span>{elements.length} öğe</span>
            <button
              onClick={() => setShowAddPanel(true)}
              className="voice-btn px-3 py-1.5 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-lg text-xs hover:from-green-400 hover:to-emerald-500"
            >
              + Yeni Ekle
            </button>
          </div>

          {/* Filter tabs */}
          <div className="flex flex-wrap gap-1">
            <button
              onClick={() => setFilterType("all")}
              className={`px-2 py-1 rounded text-[10px] font-semibold transition-all ${
                filterType === "all" ? "bg-sky-500/20 text-sky-400 border border-sky-500/30" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              Tümü
            </button>
            {TYPE_LIST.map((t) => {
              const tpl = ELEMENT_TEMPLATES[t];
              const count = elements.filter((e) => e.type === t).length;
              if (count === 0) return null;
              return (
                <button
                  key={t}
                  onClick={() => setFilterType(t)}
                  className={`px-2 py-1 rounded text-[10px] font-semibold transition-all ${
                    filterType === t ? "bg-sky-500/20 text-sky-400 border border-sky-500/30" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  {tpl.icon} {count}
                </button>
              );
            })}
          </div>
        </div>

        {/* Element list */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filtered.map((el) => {
            const tpl = ELEMENT_TEMPLATES[el.type];
            const isSelected = selectedId === el.id;
            return (
              <button
                key={el.id}
                onClick={() => onSelectOnMap(el.id)}
                className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 transition-all ${
                  isSelected
                    ? "bg-sky-500/15 border border-sky-500/40 ring-1 ring-sky-400/20"
                    : "hover:bg-slate-800/50 border border-transparent"
                }`}
              >
                <div className="w-9 h-9 rounded-lg flex items-center justify-center text-lg flex-shrink-0"
                  style={{ backgroundColor: el.color + "20", border: `1px solid ${el.color}40` }}>
                  {tpl.icon}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-white truncate">{el.label}</div>
                  <div className="text-[10px] text-slate-500 truncate">
                    {TYPE_NAMES[el.type]} · ({el.x.toFixed(0)}, {el.z.toFixed(0)})
                  </div>
                </div>
                {el.taskId && (
                  <span className="text-[9px] px-1.5 py-0.5 bg-amber-500/10 text-amber-400 rounded font-semibold border border-amber-500/20">
                    G{el.taskId}
                  </span>
                )}
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="text-center py-10 text-slate-500 text-sm">
              Bu tipte öğe yok
            </div>
          )}
        </div>
      </div>

      {/* ====== RIGHT PANEL — PROPERTY EDITOR ====== */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedEl ? (
          <PropertyEditor
            element={selectedEl}
            elements={elements}
            onUpdate={updateProp}
            onDelete={handleDelete}
            onDuplicate={handleDuplicate}
            onSelectOnMap={onSelectOnMap}
            colorPresets={colorPresets}
            onSpeak={onSpeak}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4 opacity-30">🗺️</div>
              <h3 className="text-xl font-bold text-slate-400 mb-2">Öğe Seçin</h3>
              <p className="text-sm text-slate-500">
                Soldaki listeden bir öğe seçin veya &quot;+ Yeni Ekle&quot; ile başlayın
              </p>
              <button
                onClick={() => setShowAddPanel(true)}
                className="voice-btn mt-4 px-6 py-2.5 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-xl"
              >
                + Yeni Öğe Ekle
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ====== ADD MODAL ====== */}
      {showAddPanel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="glass-card rounded-3xl p-6 w-full max-w-lg mx-4 animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-xl font-black text-white">➕ Yeni Öğe Ekle</h3>
              <button onClick={() => setShowAddPanel(false)} className="text-slate-400 hover:text-white text-2xl leading-none">&times;</button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-5">
              {TYPE_LIST.filter(t => t !== "character").map((t) => {
                const tpl = ELEMENT_TEMPLATES[t];
                return (
                  <button
                    key={t}
                    onClick={() => setAddType(t)}
                    className={`p-3 rounded-xl text-center transition-all ${
                      addType === t
                        ? "bg-sky-500/15 border-2 border-sky-400/50 ring-1 ring-sky-400/20"
                        : "glass-light border border-transparent hover:border-slate-600"
                    }`}
                  >
                    <div className="text-2xl mb-1">{tpl.icon}</div>
                    <div className="text-[10px] font-semibold text-white">{tpl.label}</div>
                  </button>
                );
              })}
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleAdd}
                className="flex-1 voice-btn py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-xl text-lg"
              >
                ✅ Ekle
              </button>
              <button
                onClick={() => setShowAddPanel(false)}
                className="voice-btn py-3 px-6 glass text-white font-bold rounded-xl"
              >
                İptal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ===================================================================
// PROPERTY EDITOR — Seçili öğenin TÜM özelliklerini düzenler
// ===================================================================
function PropertyEditor({
  element,
  elements,
  onUpdate,
  onDelete,
  onDuplicate,
  onSelectOnMap,
  colorPresets,
  onSpeak,
}: {
  element: MapElement;
  elements: MapElement[];
  onUpdate: (id: string, key: string, value: any) => void;
  onDelete: (id: string) => void;
  onDuplicate: (id: string) => void;
  onSelectOnMap: (id: string | null) => void;
  colorPresets: string[];
  onSpeak: (text: string, opts?: any) => void;
}) {
  const el = element;
  const tpl = ELEMENT_TEMPLATES[el.type];

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="mb-3">
      <label className="text-xs font-semibold text-slate-400 mb-1.5 block">{label}</label>
      {children}
    </div>
  );

  const TextInput = ({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) => (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full px-3 py-2 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/50 transition-all"
    />
  );

  const NumberInput = ({ value, onChange, min, max, step }: { value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number }) => (
    <div className="flex items-center gap-2">
      <input
        type="range"
        min={min ?? -50}
        max={max ?? 50}
        step={step ?? 0.5}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="flex-1 accent-sky-400"
      />
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
        step={step ?? 0.5}
        className="w-20 px-2 py-1.5 bg-slate-800/50 border border-slate-600/50 rounded-lg text-white text-xs text-center focus:outline-none focus:border-sky-400 transition-all"
      />
    </div>
  );

  const Checkbox = ({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) => (
    <label className="flex items-center gap-2 cursor-pointer">
      <input
        type="checkbox"
        checked={value}
        onChange={(e) => onChange(e.target.checked)}
        className="w-4 h-4 rounded accent-sky-400"
      />
      <span className="text-sm text-slate-300">{label}</span>
    </label>
  );

  const Select = ({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }) => (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-3 py-2 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white text-sm focus:outline-none focus:border-sky-400 transition-all"
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  );

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
            style={{ backgroundColor: el.color + "20", border: `1px solid ${el.color}40` }}>
            {tpl.icon}
          </div>
          <div>
            <div className="text-[10px] text-sky-400 font-semibold uppercase">{TYPE_NAMES[el.type]}</div>
            <div className="text-lg font-bold text-white">{el.label}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => onDuplicate(el.id)} className="voice-btn px-3 py-1.5 glass rounded-lg text-xs text-slate-300 hover:bg-white/10">📋 Kopyala</button>
          {el.type !== "character" && (
            <button onClick={() => onDelete(el.id)} className="voice-btn px-3 py-1.5 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-400 hover:bg-red-500/20">🗑️ Sil</button>
          )}
        </div>
      </div>

      {/* Scrollable form */}
      <div className="flex-1 overflow-y-auto p-5">
        {/* === ID & Label === */}
        <div className="glass-card rounded-2xl p-4 mb-4">
          <div className="text-xs font-semibold text-sky-400 uppercase mb-3">📝 Temel Bilgiler</div>
          <Field label="Etiket / İsim">
            <TextInput value={el.label} onChange={(v) => onUpdate(el.id, "label", v)} placeholder="Örn: Okul" />
          </Field>
          <Field label="Açıklama">
            <TextInput value={el.description} onChange={(v) => onUpdate(el.id, "description", v)} placeholder="Sesli okunacak açıklama" />
          </Field>
          <Field label="ID (otomatik)">
            <div className="text-xs text-slate-500 bg-slate-800/30 px-3 py-2 rounded-lg font-mono">{el.id}</div>
          </Field>
          {el.type === "building" && (
            <Field label="Görev Bağlantısı">
              <div className="flex items-center gap-2">
                <select
                  value={el.taskId || ""}
                  onChange={(e) => onUpdate(el.id, "taskId", e.target.value ? parseInt(e.target.value) : undefined)}
                  className="flex-1 px-3 py-2 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white text-sm focus:outline-none focus:border-sky-400"
                >
                  <option value="">Bağlı değil</option>
                  {Array.from({ length: 10 }, (_, i) => (
                    <option key={i + 1} value={i + 1}>Görev {i + 1}</option>
                  ))}
                </select>
                {el.taskId && <span className="text-amber-400 text-xs font-semibold">🎯 G{el.taskId}</span>}
              </div>
            </Field>
          )}
          <Checkbox label="Etkileşimli (üzerine gelince bilgi)" value={el.interactive || false} onChange={(v) => onUpdate(el.id, "interactive", v)} />
        </div>

        {/* === POSITION === */}
        <div className="glass-card rounded-2xl p-4 mb-4">
          <div className="text-xs font-semibold text-sky-400 uppercase mb-3">📍 Konum</div>
          <Field label={`X (Sol↔Sağ): ${el.x.toFixed(1)}`}>
            <NumberInput value={el.x} onChange={(v) => onUpdate(el.id, "x", v)} min={-50} max={50} step={0.5} />
          </Field>
          <Field label={`Y (Yükseklik): ${el.y.toFixed(1)}`}>
            <NumberInput value={el.y} onChange={(v) => onUpdate(el.id, "y", v)} min={0} max={20} step={0.1} />
          </Field>
          <Field label={`Z (İleri↔Geri): ${el.z.toFixed(1)}`}>
            <NumberInput value={el.z} onChange={(v) => onUpdate(el.id, "z", v)} min={-50} max={50} step={0.5} />
          </Field>
        </div>

        {/* === SIZE === */}
        <div className="glass-card rounded-2xl p-4 mb-4">
          <div className="text-xs font-semibold text-sky-400 uppercase mb-3">📐 Boyut</div>
          <Field label={`Genişlik: ${el.width.toFixed(1)}`}>
            <NumberInput value={el.width} onChange={(v) => onUpdate(el.id, "width", v)} min={0.1} max={60} step={0.5} />
          </Field>
          <Field label={`Yükseklik: ${el.height.toFixed(1)}`}>
            <NumberInput value={el.height} onChange={(v) => onUpdate(el.id, "height", v)} min={0} max={20} step={0.5} />
          </Field>
          <Field label={`Derinlik: ${el.depth.toFixed(1)}`}>
            <NumberInput value={el.depth} onChange={(v) => onUpdate(el.id, "depth", v)} min={0.1} max={60} step={0.5} />
          </Field>
        </div>

        {/* === COLOR === */}
        <div className="glass-card rounded-2xl p-4 mb-4">
          <div className="text-xs font-semibold text-sky-400 uppercase mb-3">🎨 Renk</div>
          <div className="flex items-center gap-3 mb-3">
            <input
              type="color"
              value={el.color}
              onChange={(e) => onUpdate(el.id, "color", e.target.value)}
              className="w-12 h-10 rounded-lg cursor-pointer border-0 bg-transparent"
            />
            <input
              type="text"
              value={el.color}
              onChange={(e) => onUpdate(el.id, "color", e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white text-sm font-mono focus:outline-none focus:border-sky-400"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {colorPresets.map((c) => (
              <button
                key={c}
                onClick={() => onUpdate(el.id, "color", c)}
                className={`w-7 h-7 rounded-lg transition-all ${el.color === c ? "ring-2 ring-white ring-offset-2 ring-offset-slate-900 scale-110" : "hover:scale-110"}`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>

        {/* === BUILDING-SPECIFIC === */}
        {el.type === "building" && (
          <div className="glass-card rounded-2xl p-4 mb-4">
            <div className="text-xs font-semibold text-sky-400 uppercase mb-3">🏢 Bina Özellikleri</div>
            <Field label={`Kat Sayısı: ${el.floors || 1}`}>
              <NumberInput value={el.floors || 1} onChange={(v) => onUpdate(el.id, "floors", Math.max(1, Math.round(v)))} min={1} max={10} step={1} />
            </Field>
            <Field label="Çatı Tipi">
              <Select value={el.roofType || "flat"} onChange={(v) => onUpdate(el.id, "roofType", v)} options={ROOF_OPTIONS} />
            </Field>
          </div>
        )}

        {/* === TREE-SPECIFIC === */}
        {el.type === "tree" && (
          <div className="glass-card rounded-2xl p-4 mb-4">
            <div className="text-xs font-semibold text-sky-400 uppercase mb-3">🌳 Ağaç Özellikleri</div>
            <Field label={`Ölçek: ${(el.scale || 1).toFixed(1)}`}>
              <NumberInput value={el.scale || 1} onChange={(v) => onUpdate(el.id, "scale", v)} min={0.3} max={3} step={0.1} />
            </Field>
          </div>
        )}

        {/* === CAR-SPECIFIC === */}
        {el.type === "car" && (
          <div className="glass-card rounded-2xl p-4 mb-4">
            <div className="text-xs font-semibold text-sky-400 uppercase mb-3">🚗 Araba Özellikleri</div>
            <Field label="Yön">
              <Select
                value={String(el.dirX || 1)}
                onChange={(v) => onUpdate(el.id, "dirX", parseInt(v))}
                options={[{ value: "1", label: "Sağa →" }, { value: "-1", label: "Sola ←" }]}
              />
            </Field>
            <Field label={`Hız: ${(el.speed || 3).toFixed(1)}`}>
              <NumberInput value={el.speed || 3} onChange={(v) => onUpdate(el.id, "speed", v)} min={0.5} max={10} step={0.5} />
            </Field>
          </div>
        )}

        {/* === ROAD-SPECIFIC === */}
        {el.type === "road" && (
          <div className="glass-card rounded-2xl p-4 mb-4">
            <div className="text-xs font-semibold text-sky-400 uppercase mb-3">🛣️ Yol Özellikleri</div>
            <Field label="Yön">
              <Select
                value={el.roadRotY ? "1" : "0"}
                onChange={(v) => onUpdate(el.id, "roadRotY", v === "1" ? Math.PI / 2 : 0)}
                options={[{ value: "0", label: "Yatay (↔)" }, { value: "1", label: "Dikey (↕)" }]}
              />
            </Field>
          </div>
        )}
      </div>

      {/* Bottom bar */}
      <div className="p-4 border-t border-slate-800 flex gap-3">
        <button
          onClick={() => { onSelectOnMap(null); onSpeak(`${el.label} öğesi seçildi. Konumu ve özellikleri ayarlandı.`); }}
          className="flex-1 voice-btn py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold rounded-xl"
        >
          ✅ Değişiklikleri Kaydet
        </button>
        <button
          onClick={() => onSelectOnMap(null)}
          className="voice-btn py-3 px-6 glass text-white font-bold rounded-xl hover:bg-white/10"
        >
          Kapat
        </button>
      </div>
    </div>
  );
}
