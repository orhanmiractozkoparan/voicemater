"use client";

import { useState } from "react";

interface Task {
  id: number;
  title: string;
  description: string;
  difficulty: "Kolay" | "Orta" | "Zor";
  hint: string;
  icon: string;
  completed: boolean;
  steps?: string[];
  reward?: string;
}

interface TaskPanelProps {
  currentTask: number;
  tasks: Task[];
  onSelectTask: (id: number) => void;
  onSpeak: (text: string, options?: any) => void;
  isListening: boolean;
}

const difficultyConfig = {
  Kolay: { color: "from-green-500 to-emerald-600", bg: "bg-green-500/10", border: "border-green-500/30", text: "text-green-400", emoji: "🟢", stars: 1 },
  Orta: { color: "from-amber-500 to-orange-600", bg: "bg-amber-500/10", border: "border-amber-500/30", text: "text-amber-400", emoji: "🟡", stars: 2 },
  Zor: { color: "from-red-500 to-rose-600", bg: "bg-red-500/10", border: "border-red-500/30", text: "text-red-400", emoji: "🔴", stars: 3 },
};

export function TaskPanel3D({ currentTask, tasks, onSelectTask, onSpeak, isListening }: TaskPanelProps) {
  const [hoveredTask, setHoveredTask] = useState<number | null>(null);
  const [expandedTask, setExpandedTask] = useState<number | null>(null);

  const completedCount = tasks.filter(t => t.completed).length;
  const progress = (completedCount / tasks.length) * 100;

  const handleMouseEnter = (task: Task) => {
    setHoveredTask(task.id);
    onSpeak(`${task.id}. görev: ${task.title}. Zorluk: ${task.difficulty}. ${task.hint}`, { rate: 0.85, pitch: 0.9 });
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4">
      {/* Header with stats */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-3xl font-black bg-gradient-to-r from-sky-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent mb-1">
              📋 Görev Panosu
            </h2>
            <p className="text-slate-400 text-sm">
              Görev numarasını sesli söyleyin veya tıklayın
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="glass rounded-2xl px-5 py-3 flex items-center gap-3">
              <div className="text-2xl">🏆</div>
              <div>
                <div className="text-lg font-bold text-white">{completedCount}/{tasks.length}</div>
                <div className="text-xs text-slate-400">Tamamlanan</div>
              </div>
            </div>
            {isListening && (
              <div className="glass rounded-2xl px-4 py-3 flex items-center gap-2 animate-mic">
                <span className="text-xl">🎤</span>
                <span className="text-sm text-green-400 font-semibold">Dinleniyor</span>
              </div>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700/50">
          <div
            className="h-full rounded-full transition-all duration-1000 ease-out relative overflow-hidden"
            style={{ width: `${progress}%`, background: "linear-gradient(90deg, #22c55e, #38bdf8, #818cf8)" }}
          >
            <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)", animation: "shimmer 2s linear infinite" }} />
          </div>
        </div>
        <div className="flex justify-between mt-2 text-xs text-slate-500">
          <span>Başlangıç</span>
          <span className="text-sky-400 font-semibold">%{Math.round(progress)}</span>
          <span>Tamamlanmış</span>
        </div>
      </div>

      {/* Task Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {tasks.map((task, index) => {
          const isCurrent = task.id === currentTask;
          const isCompleted = task.completed;
          const isHovered = hoveredTask === task.id;
          const isExpanded = expandedTask === task.id;
          const config = difficultyConfig[task.difficulty];

          return (
            <div
              key={task.id}
              className={`task-card relative rounded-2xl overflow-hidden transition-all duration-300 ${
                isCompleted
                  ? "glass-card border-green-500/30 opacity-80"
                  : isCurrent
                  ? "glass-card border-sky-400/50 animate-pulse-glow"
                  : isHovered
                  ? "glass-card border-sky-400/30"
                  : "glass-card border-slate-700/30"
              }`}
              onMouseEnter={() => handleMouseEnter(task)}
              onMouseLeave={() => { setHoveredTask(null); }}
              onClick={() => {
                setExpandedTask(isExpanded ? null : task.id);
                onSelectTask(task.id);
              }}
              tabIndex={0}
              role="listitem"
              aria-label={`Görev ${task.id}: ${task.title}. ${task.description}. Zorluk: ${task.difficulty}`}
              style={{ animationDelay: `${index * 0.08}s` }}
            >
              {/* Top gradient bar */}
              <div className={`h-1.5 w-full bg-gradient-to-r ${config.color}`} />

              {/* Task Number Badge */}
              <div className="p-5 pb-3">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`relative w-11 h-11 rounded-xl flex items-center justify-center text-lg font-black ${
                      isCompleted
                        ? "bg-green-500/20 text-green-400 border border-green-500/30"
                        : isCurrent
                        ? "bg-sky-500/20 text-sky-400 border border-sky-500/30"
                        : "bg-slate-700/50 text-slate-400 border border-slate-600/30"
                    }`}>
                      {isCompleted ? "✓" : task.id}
                      {isCurrent && !isCompleted && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-sky-400 rounded-full animate-pulse" />
                      )}
                    </div>
                    <div>
                      <div className="text-2xl">{task.icon}</div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${config.bg} ${config.text} ${config.border} border`}>
                      {config.emoji} {task.difficulty}
                    </span>
                    <div className="flex gap-0.5">
                      {Array.from({ length: config.stars }).map((_, i) => (
                        <span key={i} className="text-[10px]">⭐</span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-white mb-2 leading-tight">
                  {task.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-slate-400 leading-relaxed">
                  {task.description}
                </p>

                {/* Completed Badge */}
                {isCompleted && (
                  <div className="mt-3 flex items-center gap-2 px-3 py-1.5 bg-green-500/10 rounded-lg border border-green-500/20">
                    <span className="text-sm">✅</span>
                    <span className="text-xs text-green-400 font-semibold">Tamamlandı!</span>
                  </div>
                )}

                {/* Current Task Badge */}
                {isCurrent && !isCompleted && (
                  <div className="mt-3 flex items-center gap-2 px-3 py-1.5 bg-sky-500/10 rounded-lg border border-sky-500/20">
                    <div className="w-2 h-2 bg-sky-400 rounded-full animate-pulse" />
                    <span className="text-xs text-sky-400 font-semibold">Şu an bu görevde</span>
                  </div>
                )}

                {/* Expanded details */}
                {(isHovered || isExpanded) && !isCompleted && (
                  <div className="mt-3 pt-3 border-t border-slate-700/50 animate-slide-up">
                    <p className="text-xs text-sky-300 font-semibold mb-2 flex items-center gap-1">
                      💡 İpucu:
                    </p>
                    <p className="text-xs text-slate-300 leading-relaxed">{task.hint}</p>
                    {task.steps && task.steps.length > 0 && (
                      <div className="mt-3">
                        <p className="text-xs text-indigo-300 font-semibold mb-1">📝 Adımlar:</p>
                        <ol className="text-[11px] text-slate-400 space-y-1 ml-3 list-decimal">
                          {task.steps.map((step, i) => (
                            <li key={i}>{step}</li>
                          ))}
                        </ol>
                      </div>
                    )}
                    {task.reward && (
                      <div className="mt-2 flex items-center gap-1 text-xs text-amber-400">
                        <span>🎁</span>
                        <span>{task.reward}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
