"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useVoiceEngine } from "@/hooks/useVoiceEngine";
import { MapElement, DEFAULT_MAP } from "@/lib/mapData";
import dynamic from "next/dynamic";

const CityScene3D = dynamic(() => import("@/components/CityScene3D"), { ssr: false, loading: () => <LoadBox text="3D Şehir Yükleniyor..." /> });
const TaskPanel3D = dynamic(() => import("@/components/TaskPanel3D").then(m => ({ default: m.TaskPanel3D })), { ssr: false, loading: () => <LoadBox text="Görevler Yükleniyor..." /> });
const TaskCreator = dynamic(() => import("@/components/TaskCreator").then(m => ({ default: m.TaskCreator })), { ssr: false, loading: () => <LoadBox text="Tasarımcı Yükleniyor..." /> });
const UE5Editor = dynamic(() => import("@/components/UE5Editor").then(m => ({ default: m.UE5Editor })), { ssr: false, loading: () => <LoadBox text="Unreal Engine 5 Editör Yükleniyor..." /> });
const UE5Viewport = dynamic(() => import("@/components/UE5Viewport"), { ssr: false, loading: () => <LoadBox text="Viewport Yükleniyor..." /> });

function LoadBox({ text }: { text?: string }) {
  return (
    <div className="w-full rounded-3xl border border-slate-700/50 flex items-center justify-center bg-[#0a1628]" style={{ height: "65vh", minHeight: "450px" }}>
      <div className="text-center"><div className="text-5xl mb-4 animate-bounce-in">🏙️</div><p className="text-sky-400 font-bold text-lg">{text || "Yükleniyor..."}</p></div>
    </div>
  );
}

interface Task {
  id: number; title: string; description: string; difficulty: "Kolay" | "Orta" | "Zor";
  hint: string; icon: string; completed: boolean; steps?: string[]; reward?: string;
  characterX: number; characterY: number; characterZ: number;
}

const defaultTasks: Task[] = [
  { id: 1, title: "Yaya Geçidinden Geç", description: "Yaya geçidini bul ve karşıya güvenli şekilde geç.", difficulty: "Kolay", hint: "Yaya geçitleri beyaz çizgilerle işaretlenmiştir.", icon: "🦓", completed: false, steps: ["Yaya geçidine yaklaş", "Dur ve sola bak", "Sağa bak", "Güvenliyse karşıya geç"], reward: "+50 puan", characterX: -15, characterY: 0, characterZ: 3 },
  { id: 2, title: "Trafik Işıklarında Bekle", description: "Trafik ışıklarına gel. Yeşil yana kadar bekle.", difficulty: "Kolay", hint: "Yeşil = geç, Sarı = bekle, Kırmızı = dur!", icon: "🚦", completed: false, steps: ["Trafik ışığına gel", "Kontrol et", "Yeşil yanana kadar bekle", "Karşıya geç"], reward: "+50 puan", characterX: 15, characterY: 0, characterZ: 3 },
  { id: 3, title: "Okul Bölgesinden Geç", description: "Okul bölgesinde yavaşla.", difficulty: "Kolay", hint: "Çocuklar aniden yola atlayabilir!", icon: "🏫", completed: false, steps: ["Tabelayı duy", "Yavaşla", "İlerle", "Geç"], reward: "+75 puan", characterX: -25, characterY: 0, characterZ: -15 },
  { id: 4, title: "Hastane Acil Çıkışı", description: "Hastane önünde ambulanslara yol ver.", difficulty: "Orta", hint: "Siren sesi duyulduğunda acil yol verin!", icon: "🏥", completed: false, steps: ["Hastaneye gel", "Siren dinle", "Yol ver", "Geç"], reward: "+100 puan", characterX: 25, characterY: 0, characterZ: -17 },
  { id: 5, title: "Park Yolunda Yürü", description: "Park içindeki yolu takip et.", difficulty: "Orta", hint: "Toprak yoldan dışarı çıkmayın.", icon: "🌳", completed: false, steps: ["Park girişini bul", "Yola gir", "Takip et", "Çıkışa ulaş"], reward: "+100 puan", characterX: 3, characterY: 0, characterZ: 22 },
  { id: 6, title: "Kavşaktan Dön", description: "Kavşakta dikkatli ilerle.", difficulty: "Orta", hint: "Sesli sinyali dinleyerek yönü anlayın.", icon: "🔄", completed: false, steps: ["Kavşağa gel", "Sinyali dinle", "Yönü kontrol et", "Dön"], reward: "+100 puan", characterX: 15, characterY: 0, characterZ: -8 },
  { id: 7, title: "Otobüs Durağını Bul", description: "Durağı bul, otobüsü bekle.", difficulty: "Zor", hint: "Mavi tabela ve bank var.", icon: "🚌", completed: false, steps: ["Durağı ara", "Tabelayı bul", "Otur", "Bekle", "Hazırlan"], reward: "+150 puan", characterX: -20, characterY: 0, characterZ: 12 },
  { id: 8, title: "Marketten Alışveriş", description: "Markete gir, ürün al, kasaya git.", difficulty: "Zor", hint: "Kapı sensörü ile otomatik açılır.", icon: "🛒", completed: false, steps: ["Yaklaş", "Gir", "Ürün ara", "Kasaya git", "Öde", "Çık"], reward: "+150 puan", characterX: 0, characterY: 0, characterZ: 12 },
  { id: 9, title: "Camiyi Ziyaret Et", description: "Camiyi bul, avlusuna gir.", difficulty: "Zor", hint: "Minare sesinden yerini anlayın.", icon: "☪", completed: false, steps: ["Sesini dinle", "Girişi bul", "Ayakkabı çıkar", "Gir", "Tamamla"], reward: "+150 puan", characterX: 0, characterY: 0, characterZ: -18 },
  { id: 10, title: "Varış Noktasına Ulaş", description: "Bayrağa ulaş ve oyunu bitir!", difficulty: "Zor", hint: "Bayrak kuzeyde.", icon: "🏁", completed: false, steps: ["Hazırlan", "Yola çık", "Bayrağı gör", "Ulaş!"], reward: "🏆 Oyunu Tamamladın!", characterX: 0, characterY: 0, characterZ: -22 },
];

type GameScreen = "welcome" | "map" | "tasks" | "creator" | "editor";

export function GameClient() {
  const voice = useVoiceEngine();
  const [screen, setScreen] = useState<GameScreen>("welcome");
  const [currentTask, setCurrentTask] = useState(1);
  const [tasks, setTasks] = useState<Task[]>(defaultTasks);
  const [mapElements, setMapElements] = useState<MapElement[]>(DEFAULT_MAP);
  const [characterPos, setCharacterPos] = useState({ x: 0, y: 0, z: 25 });
  const [taskCompleted, setTaskCompleted] = useState(false);
  const [hoveredObject, setHoveredObject] = useState<string | null>(null);
  const [selectedMapId, setSelectedMapId] = useState<string | null>(null);
  const [transformMode, setTransformMode] = useState<"translate" | "rotate" | "scale">("translate");
  const [snapEnabled, setSnapEnabled] = useState(true);
  const [snapValue, setSnapValue] = useState(0.5);
  const lastCmd = useRef("");
  const welcomeDone = useRef(false);

  // Welcome speak
  useEffect(() => {
    if (screen === "welcome" && !welcomeDone.current) {
      welcomeDone.current = true;
      setTimeout(() => voice.speak("Hoş geldiniz! Sokak Güvenliği Oyunu. 3D şehir haritası. On görev, harita editörü ve görev tasarlama. Başlamak için başla deyin.", { rate: 0.85, pitch: 0.85 }), 600);
    }
  }, [screen, voice.speak]);

  // Voice commands
  useEffect(() => {
    if (!voice.lastCommand) return;
    const cmd = voice.lastCommand.toLowerCase().trim();
    if (cmd === lastCmd.current) return;
    lastCmd.current = cmd;
    const n = (s: string) => s.replace(/ı/g, "i").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ş/g, "s").replace(/ö/g, "o").replace(/ç/g, "c");
    const nc = n(cmd);

    if (nc.includes("tekrar oku")) {
      if (screen === "welcome") voice.speak("Başlamak için başla, editör için editör deyin.", { rate: 0.85 });
      else if (screen === "map") { const t = tasks.find(t => t.id === currentTask); if (t) voice.speak(`Görev ${currentTask}: ${t.title}. ${t.hint}`, { rate: 0.85 }); }
      else if (screen === "tasks") voice.speak(`${tasks.length} görev. ${tasks.filter(t => t.completed).length} tamamlandı.`, { rate: 0.85 });
      else if (screen === "editor") voice.speak("Harita editörü. Öğeleri düzenleyebilirsiniz.", { rate: 0.85 });
      return;
    }
    if (nc.includes("basla")) { setScreen("tasks"); voice.speak("Oyun başlıyor!", { rate: 0.85 }); return; }
    if (nc.includes("harita") && !nc.includes("editör") && !nc.includes("editor")) { setScreen("map"); voice.speak("Harita açıldı.", { rate: 0.85 }); return; }
    if (nc.includes("gorevler") || nc.includes("görevler")) { setScreen("tasks"); voice.speak("Görev listesi.", { rate: 0.85 }); return; }
    if (nc.includes("editör") || nc.includes("editor")) { setScreen("editor"); voice.speak("Harita editörü açıldı.", { rate: 0.85 }); return; }
    if (nc.includes("tasarla")) { setScreen("creator"); voice.speak("Görev tasarlama.", { rate: 0.85 }); return; }
    if (nc.includes("tamamla") && screen === "map" && !taskCompleted) { completeTask(); return; }
    if (nc.includes("sonraki")) { if (currentTask < tasks.length) goTo(currentTask + 1); return; }
    if (nc.includes("onceki") || nc.includes("geri")) { if (currentTask > 1) goTo(currentTask - 1); return; }
    if (nc.includes("ipucu")) { const t = tasks.find(t => t.id === currentTask); if (t) voice.speak(`İpucu: ${t.hint}`, { rate: 0.85 }); return; }
    if (nc.includes("yardim")) { voice.speak("Komutlar: başla, harita, görevler, editör, tasarlama, tamamla, sonraki, önceki, ipucu, tekrar oku.", { rate: 0.85 }); return; }
    const pn = parseNum(nc);
    if (pn && pn >= 1 && pn <= tasks.length) goTo(pn);
  }, [voice.lastCommand]);

  const parseNum = (c: string): number | null => {
    const m: Record<string, number> = { bir: 1, "1": 1, iki: 2, "2": 2, uc: 3, "3": 3, dort: 4, "4": 4, bes: 5, "5": 5, alti: 6, "6": 6, yedi: 7, "7": 7, sekiz: 8, "8": 8, dokuz: 9, "9": 9, on: 10, "10": 10 };
    for (const [k, v] of Object.entries(m)) if (c.includes(k)) return v;
    return null;
  };

  const goTo = useCallback((id: number) => {
    if (id < 1 || id > tasks.length) return;
    const t = tasks[id - 1];
    setCurrentTask(id);
    setCharacterPos({ x: t.characterX, y: t.characterY, z: t.characterZ });
    setTaskCompleted(t.completed);
    setScreen("map");
    voice.speak(`${id}. görev: ${t.title}. ${t.description}`, { rate: 0.85 });
  }, [tasks, voice.speak]);

  const completeTask = useCallback(() => {
    setTaskCompleted(true);
    const t = tasks.find(t => t.id === currentTask);
    voice.speak(`Tebrikler! "${t?.title}" tamamlandı! ${t?.reward || ""}`, { rate: 0.9 });
    setTasks(prev => prev.map(t => t.id === currentTask ? { ...t, completed: true } : t));
  }, [currentTask, tasks, voice.speak]);

  useEffect(() => {
    if (screen !== "welcome" && !voice.isListening) {
      const timer = setTimeout(() => voice.startListening(), 800);
      return () => clearTimeout(timer);
    }
  }, [screen, voice.isListening, voice.startListening]);

  const completedCount = tasks.filter(t => t.completed).length;
  const task = tasks.find(t => t.id === currentTask);

  // ===== WELCOME =====
  if (screen === "welcome") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 20 }).map((_, i) => (
            <div key={i} className="absolute rounded-full" style={{ width: 3 + (i % 4), height: 3 + (i % 4), left: `${(i * 5.3) % 100}%`, top: `${(i * 7.7) % 100}%`, background: ["#38bdf8", "#818cf8", "#c084fc", "#22c55e"][i % 4], opacity: 0.12 + (i % 3) * 0.08, animation: `float ${3 + (i % 4)}s ease-in-out ${i * 0.2}s infinite` }} />
          ))}
        </div>
        <div className="relative z-10 max-w-4xl w-full text-center">
          <div className="mb-8" style={{ animation: "bounce-in 0.8s ease-out" }}>
            <div className="w-36 h-36 mx-auto rounded-3xl flex items-center justify-center text-7xl shadow-2xl mb-6" style={{ background: "linear-gradient(135deg, #38bdf8, #6366f1, #a855f7)", transform: "perspective(400px) rotateY(-5deg) rotateX(5deg)", boxShadow: "0 20px 60px rgba(99, 102, 241, 0.4)" }}>🧑‍🦯</div>
            <h1 className="text-5xl md:text-7xl font-black mb-2 shimmer-text">Sokak Güvenliği</h1>
            <h2 className="text-3xl md:text-4xl font-black text-white mb-4">3D Oyunu</h2>
            <p className="text-lg text-slate-400 max-w-xl mx-auto">Three.js 3D şehir • Harita editörü • Görev tasarlama</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-10">
            {[
              { e: "🏙️", t: "3D Şehir" }, { e: "🎤", t: "Sesli Komut" }, { e: "🎯", t: "10 Görev" },
              { e: "🛠️", t: "Harita Editörü" }, { e: "📝", t: "Görev Tasarla" },
            ].map((f, i) => (
              <div key={i} className="glass-card rounded-2xl p-4 text-center" style={{ animation: `slide-up 0.5s ease-out ${0.2 + i * 0.1}s both` }}>
                <div className="text-3xl mb-1">{f.e}</div><h3 className="text-xs font-bold text-white">{f.t}</h3>
              </div>
            ))}
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <button className="voice-btn px-12 py-5 text-white font-black text-xl rounded-2xl shadow-2xl" style={{ background: "linear-gradient(135deg, #38bdf8, #6366f1, #a855f7)", boxShadow: "0 15px 40px rgba(99,102,241,0.35)" }} onClick={() => { setScreen("tasks"); voice.speak("Oyun başlıyor!", { rate: 0.85 }); }}>🚀 Oyuna Başla</button>
            <button className="voice-btn px-10 py-5 glass text-white font-bold text-lg rounded-2xl hover:bg-white/10" onClick={() => { setScreen("editor"); voice.speak("Harita editörü.", { rate: 0.85 }); }}>🛠️ Harita Editörü</button>
            <button className="voice-btn px-10 py-5 glass text-white font-bold text-lg rounded-2xl hover:bg-white/10" onClick={() => { setScreen("creator"); voice.speak("Görev tasarlama.", { rate: 0.85 }); }}>📝 Görev Tasarla</button>
            <button className="voice-btn px-6 py-5 glass text-white font-bold text-lg rounded-2xl hover:bg-white/10" onClick={() => voice.speak("Başlamak için başla deyin.", { rate: 0.85 })}>🔊 Oku</button>
          </div>
        </div>
      </div>
    );
  }

  // ===== MAP =====
  if (screen === "map") {
    return (
      <div className="min-h-screen p-3 md:p-5">
        <div className="max-w-7xl mx-auto mb-3 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <button className="voice-btn px-3 py-2 glass rounded-xl text-sm text-white hover:bg-white/10" onClick={() => setScreen("tasks")}>📋</button>
            <button className="voice-btn px-3 py-2 glass rounded-xl text-sm text-white hover:bg-white/10" onClick={() => setScreen("editor")}>🛠️</button>
            <button className="voice-btn px-3 py-2 glass rounded-xl text-sm text-white hover:bg-white/10" onClick={() => setScreen("welcome")}>🏠</button>
          </div>
          <div className="glass rounded-xl px-4 py-2 flex items-center gap-3">
            <span className="text-xl">{task?.icon}</span>
            <div><div className="text-xs text-slate-400">Görev {currentTask}/{tasks.length}</div><div className="text-sm text-white font-bold">{task?.title}</div></div>
          </div>
          <div className="flex items-center gap-2">
            <button className={`voice-btn px-4 py-2 rounded-xl text-sm font-semibold ${voice.isListening ? "bg-green-600 animate-mic text-white" : "glass text-slate-300"}`} onClick={() => voice.isListening ? voice.stopListening() : voice.startListening()}>{voice.isListening ? "🎤" : "🔇"}</button>
            <button className="voice-btn px-4 py-2 bg-sky-600 text-white rounded-xl text-sm hover:bg-sky-500" onClick={() => { if (task) voice.speak(`Görev ${currentTask}: ${task.title}. ${task.hint}`, { rate: 0.85 }); }}>🔊</button>
          </div>
        </div>
        <CityScene3D elements={mapElements} currentTask={currentTask} taskCompleted={taskCompleted} characterPosition={characterPos} onHoverObject={setHoveredObject} hoveredObject={hoveredObject} selectedElementId={selectedMapId} />
        <div className="max-w-7xl mx-auto mt-4 flex flex-wrap gap-3 justify-center">
          {!taskCompleted ? (
            <button className="voice-btn px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-xl text-lg shadow-lg" onClick={completeTask}>✅ Görevi Tamamla</button>
          ) : (
            <button className="voice-btn px-8 py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold rounded-xl text-lg shadow-lg animate-bounce-in" onClick={() => { if (currentTask < tasks.length) goTo(currentTask + 1); else voice.speak("Tüm görevler tamamlandı!", { rate: 0.9 }); }}>{currentTask < tasks.length ? "➡️ Sonraki" : "🏆 Bitir"}</button>
          )}
          <button className="voice-btn px-5 py-3 glass text-white font-bold rounded-xl hover:bg-white/10" onClick={() => { if (task) voice.speak(`İpucu: ${task.hint}`, { rate: 0.85 }); }}>💡</button>
          {currentTask > 1 && <button className="voice-btn px-5 py-3 glass text-white font-bold rounded-xl hover:bg-white/10" onClick={() => goTo(currentTask - 1)}>⬅️</button>}
          {currentTask < tasks.length && !taskCompleted && <button className="voice-btn px-5 py-3 glass text-white font-bold rounded-xl hover:bg-white/10" onClick={() => goTo(currentTask + 1)}>➡️</button>}
        </div>
      </div>
    );
  }

  // ===== TASKS =====
  if (screen === "tasks") {
    return (
      <div className="min-h-screen p-4 md:p-6">
        <div className="max-w-6xl mx-auto mb-6 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <button className="voice-btn px-3 py-2 glass rounded-xl text-sm text-white hover:bg-white/10" onClick={() => setScreen("welcome")}>← Ana Menü</button>
            <button className="voice-btn px-3 py-2 glass rounded-xl text-sm text-white hover:bg-white/10" onClick={() => setScreen("editor")}>🛠️ Editör</button>
          </div>
          <div className="flex items-center gap-2">
            <button className={`voice-btn px-4 py-2 rounded-xl text-sm font-semibold ${voice.isListening ? "bg-green-600 animate-mic text-white" : "glass text-slate-300"}`} onClick={() => voice.isListening ? voice.stopListening() : voice.startListening()}>{voice.isListening ? "🎤" : "🔇"}</button>
            <button className="voice-btn px-4 py-2 bg-sky-600 text-white rounded-xl text-sm hover:bg-sky-500" onClick={() => voice.speak(`${tasks.length} görev. ${completedCount} tamamlandı.`, { rate: 0.85 })}>🔊</button>
          </div>
        </div>
        <TaskPanel3D currentTask={currentTask} tasks={tasks.map(t => ({ ...t }))} onSelectTask={(id: number) => goTo(id)} onSpeak={voice.speak} isListening={voice.isListening} />
      </div>
    );
  }

  // ===== EDITOR =====
  if (screen === "editor") {
    return (
      <UE5Editor
        elements={mapElements}
        onUpdate={setMapElements}
        onBack={() => setScreen("welcome")}
        onSpeak={voice.speak}
        onPlay={() => { setScreen("map"); setTaskCompleted(false); voice.speak("Play moduna (PIE) geçildi."); }}
        selectedId={selectedMapId}
        onSelectOnMap={setSelectedMapId}
        transformMode={transformMode}
        setTransformMode={setTransformMode}
        snapEnabled={snapEnabled}
        setSnapEnabled={setSnapEnabled}
        snapValue={snapValue}
        setSnapValue={setSnapValue}
      >
        <UE5Viewport
          elements={mapElements}
          selectedId={selectedMapId}
          onSelect={setSelectedMapId}
          transformMode={transformMode}
          onElementUpdate={(id, updates) => {
            if (id === "__mode") { setTransformMode(updates.label as any); return; }
            setMapElements(elems => elems.map(e => e.id === id ? { ...e, ...updates } : e));
          }}
          playMode={false}
          characterPos={{ x: 0, y: 0, z: 25 }}
          taskCompleted={false}
          onHoverObject={setHoveredObject}
          snapEnabled={snapEnabled}
          snapValue={snapValue}
        />
      </UE5Editor>
    );
  }

  // ===== CREATOR =====
  return (
    <div className="min-h-screen p-4 md:p-6">
      <TaskCreator tasks={tasks.map(t => ({ ...t, characterX: t.characterX, characterY: t.characterY }))} onTasksUpdate={(u: any) => setTasks(u as Task[])} onBack={() => setScreen("welcome")} onSpeak={voice.speak} />
    </div>
  );
}
