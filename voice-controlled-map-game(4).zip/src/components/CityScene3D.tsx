"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import * as THREE from "three";
import { MapElement, hexToNum } from "@/lib/mapData";

interface Props {
  elements: MapElement[];
  currentTask: number;
  taskCompleted: boolean;
  characterPosition: { x: number; y: number; z: number };
  onHoverObject: (name: string | null) => void;
  hoveredObject: string | null;
  selectedElementId: string | null;
}

export default function CityScene3D({
  elements,
  currentTask,
  taskCompleted,
  characterPosition,
  onHoverObject,
  hoveredObject,
  selectedElementId,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animFrameRef = useRef(0);
  const clockRef = useRef(new THREE.Clock());
  const charGroupRef = useRef<THREE.Group | null>(null);
  const markerRef = useRef<THREE.Group | null>(null);
  const carGroupsRef = useRef<Map<string, THREE.Group>>(new Map());
  const meshMapRef = useRef<Map<string, THREE.Object3D>>(new Map());
  const raycasterRef = useRef(new THREE.Raycaster());
  const mouseRef = useRef(new THREE.Vector2(-999, -999));
  const [loaded, setLoaded] = useState(false);
  const buildKeyRef = useRef("");

  // ==================== BUILD SCENE ====================
  const buildScene = useCallback((scene: THREE.Scene, elements: MapElement[]) => {
    // Clear old dynamic objects (keep lights, sky, ground)
    const toRemove: THREE.Object3D[] = [];
    scene.traverse((obj) => {
      if (obj.userData._dynamic) toRemove.push(obj);
    });
    toRemove.forEach((o) => { o.parent?.remove(o); });
    meshMapRef.current.clear();
    carGroupsRef.current.clear();
    _trafficLightMeshes.length = 0;

    const dyn = (obj: THREE.Object3D) => { obj.userData._dynamic = true; return obj; };

    // ===================== GROUND =====================
    if (!scene.userData._hasGround) {
      const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(120, 120),
        new THREE.MeshStandardMaterial({ color: 0x2d5a27, roughness: 0.9 })
      );
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      ground.userData._dynamic = true;
      scene.add(ground);
      scene.userData._hasGround = true;
    }

    // ===================== PROCESS ELEMENTS =====================
    elements.forEach((el) => {
      const group = new THREE.Group();
      group.userData = { id: el.id, label: el.label, description: el.description, type: el.type, _dynamic: true };

      switch (el.type) {
        case "building": buildBuilding(group, el); break;
        case "road": buildRoad(group, el); break;
        case "tree": buildTree(group, el); break;
        case "car": buildCar(group, el); carGroupsRef.current.set(el.id, group); break;
        case "trafficLight": buildTrafficLight(group, el); break;
        case "crosswalk": buildCrosswalk(group, el); break;
        case "streetLamp": buildStreetLamp(group, el); break;
        case "busStop": buildBusStop(group, el); break;
        case "bench": buildBench(group, el); break;
        case "fountain": buildFountain(group, el); break;
        case "park": buildPark(group, el); break;
        case "flag": buildFlag(group, el); break;
        case "character": buildCharacter(group, el); charGroupRef.current = group; break;
      }

      group.position.set(el.x, el.y || 0, el.z);
      dyn(group);
      scene.add(group);
      meshMapRef.current.set(el.id, group);

      // Interactive hitbox
      if (el.interactive) {
        const hit = new THREE.Mesh(
          new THREE.BoxGeometry(el.width + 2, el.height + 3, el.depth + 2),
          new THREE.MeshBasicMaterial({ visible: false })
        );
        hit.position.y = (el.height || 1) / 2;
        hit.userData = { id: el.id, label: el.label, description: el.description, _dynamic: true };
        group.add(hit);
      }
    });

    // Task marker
    if (!markerRef.current) {
      const mg = new THREE.Group();
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(1, 0.08, 8, 24),
        new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 0.5, transparent: true, opacity: 0.8 })
      );
      ring.rotation.x = Math.PI / 2;
      mg.add(ring);
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.03, 0.03, 4, 8),
        new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 0.3, transparent: true, opacity: 0.4 })
      );
      beam.position.y = 2;
      mg.add(beam);
      const top = new THREE.Mesh(
        new THREE.SphereGeometry(0.25, 12, 12),
        new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 0.8 })
      );
      top.position.y = 4.2;
      mg.add(top);
      markerRef.current = mg;
      scene.add(mg);
    }

    setLoaded(true);
  }, []);

  // ==================== INIT ====================
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const w = container.clientWidth;
    const h = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a1628);
    scene.fog = new THREE.FogExp2(0x0a1628, 0.012);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(55, w / h, 0.1, 200);
    camera.position.set(25, 25, 35);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    scene.add(new THREE.AmbientLight(0x8899bb, 0.6));
    const dir = new THREE.DirectionalLight(0xfff4e0, 1.5);
    dir.position.set(20, 30, 15);
    dir.castShadow = true;
    dir.shadow.mapSize.set(2048, 2048);
    dir.shadow.camera.near = 0.5;
    dir.shadow.camera.far = 80;
    dir.shadow.camera.left = dir.shadow.camera.bottom = -40;
    dir.shadow.camera.right = dir.shadow.camera.top = 40;
    dir.shadow.bias = -0.001;
    scene.add(dir);
    scene.add(new THREE.DirectionalLight(0x6688cc, 0.3).translateX(-15).translateY(10).translateZ(-10));
    scene.add(new THREE.HemisphereLight(0x87ceeb, 0x362d1a, 0.4));

    // Sky
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(80, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0x1a2744, side: THREE.BackSide })
    );
    sky.userData._dynamic = false;
    scene.add(sky);

    // Stars
    const starPos: number[] = [];
    for (let i = 0; i < 300; i++) {
      const th = Math.random() * Math.PI * 2;
      const ph = Math.random() * Math.PI * 0.4;
      starPos.push(75 * Math.sin(ph) * Math.cos(th), 75 * Math.cos(ph) + 10, 75 * Math.sin(ph) * Math.sin(th));
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute("position", new THREE.Float32BufferAttribute(starPos, 3));
    const sp = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 0.15, transparent: true, opacity: 0.6 }));
    sp.userData._dynamic = false;
    scene.add(sp);

    // Build
    buildScene(scene, elements);

    // Camera controls
    let spherical = { r: 45, theta: Math.PI / 4, phi: Math.PI / 4 };
    const updateCam = () => {
      camera.position.set(spherical.r * Math.sin(spherical.phi) * Math.cos(spherical.theta), spherical.r * Math.cos(spherical.phi), spherical.r * Math.sin(spherical.phi) * Math.sin(spherical.theta));
      camera.lookAt(0, 0, 0);
    };
    updateCam();

    let dragging = false;
    let prev = { x: 0, y: 0 };
    const onDown = (e: PointerEvent) => { dragging = true; prev = { x: e.clientX, y: e.clientY }; };
    const onMove2 = (e: PointerEvent) => {
      mouseRef.current.x = ((e.clientX - renderer.domElement.getBoundingClientRect().left) / renderer.domElement.clientWidth) * 2 - 1;
      mouseRef.current.y = -((e.clientY - renderer.domElement.getBoundingClientRect().top) / renderer.domElement.clientHeight) * 2 + 1;
      if (!dragging) return;
      spherical.theta -= (e.clientX - prev.x) * 0.005;
      spherical.phi = Math.max(0.2, Math.min(Math.PI / 2.2, spherical.phi - (e.clientY - prev.y) * 0.005));
      prev = { x: e.clientX, y: e.clientY };
      updateCam();
    };
    const onUp = () => { dragging = false; };
    const onWheel = (e: WheelEvent) => { spherical.r = Math.max(15, Math.min(80, spherical.r + e.deltaY * 0.05)); updateCam(); };
    renderer.domElement.addEventListener("pointerdown", onDown);
    renderer.domElement.addEventListener("pointermove", onMove2);
    renderer.domElement.addEventListener("pointerup", onUp);
    renderer.domElement.addEventListener("wheel", onWheel, { passive: true });

    // Animate
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      const delta = clockRef.current.getDelta();
      const elapsed = clockRef.current.getElapsedTime();

      // Traffic lights
      const tl = _trafficLightMeshes;
      if (tl.length >= 6) {
        const ci = Math.floor(elapsed * 0.5) % 3;
        tl.forEach((m, i) => {
          const gi = Math.floor(i / 3);
          const li = i % 3;
          (m.material as THREE.MeshStandardMaterial).emissiveIntensity = li === (ci + gi) % 3 ? 1.5 : 0;
        });
      }

      // Cars
      carGroupsRef.current.forEach((cg, id) => {
        const el = elements.find((e) => e.id === id);
        if (!el) return;
        const d = el.dirX || 1;
        const s = el.speed || 3;
        cg.position.x += d * s * delta;
        if (cg.position.x > 35) cg.position.x = -35;
        if (cg.position.x < -35) cg.position.x = 35;
      });

      // Marker
      if (markerRef.current) {
        markerRef.current.children.forEach((c, i) => {
          if (i === 0) c.rotation.z = elapsed * 0.5;
          if (i === 2) c.position.y = 4.2 + Math.sin(elapsed * 2) * 0.3;
        });
        const mc = taskCompleted ? 0x22c55e : 0xef4444;
        markerRef.current.children.forEach((c) => {
          if (c instanceof THREE.Mesh && c.material instanceof THREE.MeshStandardMaterial) {
            c.material.color.setHex(mc);
            c.material.emissive.setHex(mc);
          }
        });
      }

      // Raycaster
      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      const hits = raycasterRef.current.intersectObjects(scene.children, true).filter((h) => h.object.userData.label);
      if (hits.length > 0) {
        onHoverObject(hits[0].object.userData.label);
        renderer.domElement.style.cursor = "pointer";
      } else {
        onHoverObject(null);
        renderer.domElement.style.cursor = "grab";
      }

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      renderer.domElement.removeEventListener("pointerdown", onDown);
      renderer.domElement.removeEventListener("pointermove", onMove2);
      renderer.domElement.removeEventListener("pointerup", onUp);
      renderer.domElement.removeEventListener("wheel", onWheel);
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, []); // init once

  // Rebuild when elements change
  useEffect(() => {
    if (!sceneRef.current) return;
    const key = JSON.stringify(elements.map((e) => ({ id: e.id, x: e.x, y: e.y, z: e.z, w: e.width, h: e.height, d: e.depth, c: e.color, t: e.type, l: e.label, desc: e.description, fl: e.floors, rt: e.roofType, sc: e.scale, cr: e.carColor, dx: e.dirX, sp: e.speed, rr: e.roadRotY, in: e.interactive, tk: e.taskId })));
    if (key !== buildKeyRef.current) {
      buildKeyRef.current = key;
      buildScene(sceneRef.current, elements);
    }
  }, [elements, buildScene]);

  // Character lerp
  useEffect(() => {
    if (charGroupRef.current) {
      charGroupRef.current.position.lerp(new THREE.Vector3(characterPosition.x, characterPosition.y || 0, characterPosition.z), 0.05);
    }
    if (markerRef.current) {
      markerRef.current.position.lerp(new THREE.Vector3(characterPosition.x, characterPosition.y || 0, characterPosition.z), 0.05);
    }
  }, [characterPosition]);

  // Highlight selected
  useEffect(() => {
    meshMapRef.current.forEach((obj, id) => {
      obj.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material instanceof THREE.MeshStandardMaterial) {
          if (id === selectedElementId) {
            child.material.emissiveIntensity = (child.material.emissiveIntensity || 0) + 0.3;
          }
        }
      });
    });
  }, [selectedElementId]);

  return (
    <div className="relative w-full">
      <div ref={containerRef} className="w-full rounded-3xl overflow-hidden border border-slate-700/50" style={{ height: "65vh", minHeight: "450px", background: "#0a1628" }} />
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0a1628] rounded-3xl">
          <div className="text-center"><div className="text-5xl mb-4 animate-bounce-in">🏙️</div><p className="text-sky-400 font-bold text-lg">3D Yükleniyor...</p></div>
        </div>
      )}
      {hoveredObject && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 glass rounded-2xl px-6 py-3 z-20 pointer-events-none animate-slide-down">
          <p className="text-sky-400 font-bold text-center">{hoveredObject}</p>
        </div>
      )}
      <div className="absolute bottom-3 left-3 glass-light rounded-xl px-3 py-2 text-[10px] text-slate-400 z-10">
        🖱️ Sürükle: Döndür | Tekerlek: Yakın/Uzak
      </div>
    </div>
  );
}

// ===================================================================
// 3D BUILDER FUNCTIONS
// ===================================================================

function buildBuilding(g: THREE.Group, el: MapElement) {
  const w = el.width, h = el.height, d = el.depth, color = hexToNum(el.color);
  const floors = el.floors || 1;
  const darker = new THREE.Color(color).multiplyScalar(0.7);
  const lighter = new THREE.Color(color).multiplyScalar(1.3);

  const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.1 }));
  body.position.y = h / 2; body.castShadow = true; body.receiveShadow = true; g.add(body);

  // Windows
  const winMat = new THREE.MeshStandardMaterial({ color: 0xfde68a, emissive: 0xfbbf24, emissiveIntensity: 0.3, roughness: 0.2, metalness: 0.5 });
  const darkWin = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
  const cols = Math.max(2, Math.floor(w / 1.8));
  const floorH = h / floors;
  for (let face = 0; face < 4; face++) {
    for (let r = 0; r < floors; r++) {
      for (let c = 0; c < cols; c++) {
        const win = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.8, 0.05), (r + c) % 3 !== 0 ? winMat : darkWin);
        const wx = -w / 2 + 1 + c * ((w - 2) / cols);
        const wy = r * floorH + floorH * 0.5;
        const wz = d / 2 + 0.03;
        if (face === 0) win.position.set(wx, wy, wz);
        else if (face === 1) win.position.set(wx, wy, -wz);
        else if (face === 2) { win.rotation.y = Math.PI / 2; win.position.set(d / 2 + 0.03, wy, wx); }
        else { win.rotation.y = Math.PI / 2; win.position.set(-d / 2 - 0.03, wy, wx); }
        g.add(win);
      }
    }
  }

  // Door
  g.add(new THREE.Mesh(new THREE.BoxGeometry(1.2, 2, 0.1), new THREE.MeshStandardMaterial({ color: darker, roughness: 0.4, metalness: 0.3 })).translateY(1).translateZ(d / 2 + 0.06));

  // Roof
  const rt = el.roofType || "flat";
  if (rt === "pointed") {
    const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.6, 2.5, 4), new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.4 }));
    roof.position.y = h + 1.25; roof.rotation.y = Math.PI / 4; roof.castShadow = true; g.add(roof);
  } else if (rt === "dome") {
    const dome = new THREE.Mesh(new THREE.SphereGeometry(Math.min(w, d) * 0.45, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x0d9488, roughness: 0.3, metalness: 0.3 }));
    dome.position.y = h; dome.castShadow = true; g.add(dome);
    const minaret = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, h + 4, 8), new THREE.MeshStandardMaterial({ color: 0x0d9488 }));
    minaret.position.set(w / 2 + 1, (h + 4) / 2, 0); minaret.castShadow = true; g.add(minaret);
    g.add(new THREE.Mesh(new THREE.SphereGeometry(0.5, 8, 8), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.8, roughness: 0.2 })).translateX(w / 2 + 1).translateY(h + 4.2));
  } else {
    g.add(new THREE.Mesh(new THREE.BoxGeometry(w + 0.3, 0.2, d + 0.3), new THREE.MeshStandardMaterial({ color: lighter, roughness: 0.5 })).translateY(h));
  }

  // Trim
  g.add(new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, 0.1, d + 0.1), new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.5, roughness: 0.3 })).translateY(0.05));
}

function buildRoad(g: THREE.Group, el: MapElement) {
  const isVert = !!el.roadRotY;
  const w = el.width, d = el.depth;
  const road = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.85, metalness: 0.1 }));
  road.rotation.x = -Math.PI / 2; road.receiveShadow = true; g.add(road);
  const lm = new THREE.MeshStandardMaterial({ color: 0xfbbf24, roughness: 0.5 });
  const len = isVert ? d : w;
  for (let i = -Math.floor(len / 4); i <= Math.floor(len / 4); i++) {
    const dash = new THREE.Mesh(new THREE.PlaneGeometry(isVert ? 0.12 : 1.5, isVert ? 1.5 : 0.12), lm);
    dash.rotation.x = -Math.PI / 2;
    if (isVert) dash.position.set(0, 0.07, i * 4);
    else dash.position.set(i * 4, 0.07, 0);
    g.add(dash);
  }
  const swMat = new THREE.MeshStandardMaterial({ color: 0x999999, roughness: 0.7 });
  [-1, 1].forEach(s => {
    if (isVert) {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(w, 0.15, 2.5), swMat);
      sw.position.set(0, 0.075, (d / 2 + 1.25) * s); sw.receiveShadow = true; g.add(sw);
    } else {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.15, d), swMat);
      sw.position.set((w / 2 + 1.25) * s, 0.075, 0); sw.receiveShadow = true; g.add(sw);
    }
  });
}

function buildTree(g: THREE.Group, el: MapElement) {
  const s = el.scale || 1;
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.15 * s, 0.25 * s, 2 * s, 8), new THREE.MeshStandardMaterial({ color: 0x8b5e3c, roughness: 0.9 })).translateY(s));
  [1.6, 1.2, 0.8].forEach((r, i) => {
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(r * s, 8, 8), new THREE.MeshStandardMaterial({ color: [0x16a34a, 0x22c55e, 0x15803d][i], roughness: 0.8 }));
    leaf.position.y = 2 * s + i * 0.6 * s; leaf.castShadow = true; g.add(leaf);
  });
}

function buildCar(g: THREE.Group, el: MapElement) {
  const c = hexToNum(el.carColor || el.color);
  const body = new THREE.Mesh(new THREE.BoxGeometry(2, 0.7, 1), new THREE.MeshStandardMaterial({ color: c, roughness: 0.3, metalness: 0.6 }));
  body.position.y = 0.6; body.castShadow = true; g.add(body);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1, 0.55, 0.9), new THREE.MeshStandardMaterial({ color: 0x93c5fd, roughness: 0.1, metalness: 0.8, transparent: true, opacity: 0.7 }));
  cabin.position.set(0.1, 1.15, 0); g.add(cabin);
  const wm = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.9 });
  [[-0.6, 0.5], [0.6, 0.5], [-0.6, -0.5], [0.6, -0.5]].forEach(([wx, wz]) => {
    const w = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.15, 12), wm);
    w.rotation.z = Math.PI / 2; w.position.set(wx, 0.2, wz); g.add(w);
  });
  if ((el.dirX || 1) < 0) g.rotation.y = Math.PI;
}

// Module-level shared array for traffic light meshes
const _trafficLightMeshes: THREE.Mesh[] = [];

function buildTrafficLight(g: THREE.Group, el: MapElement) {
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 4, 8), new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.6, roughness: 0.3 })).translateY(2));
  g.add(new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.6, 0.4), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, metalness: 0.4, roughness: 0.3 })).translateY(4.3));
  [0x22c55e, 0xeab308, 0xef4444].forEach((c, i) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 12), new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0, roughness: 0.1, metalness: 0.8 }));
    m.position.set(0, 4.7 - i * 0.5, 0.22); g.add(m);
    _trafficLightMeshes.push(m);
  });
}

function buildCrosswalk(g: THREE.Group, el: MapElement) {
  const sm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
  for (let i = 0; i < 6; i++) {
    const s = new THREE.Mesh(new THREE.BoxGeometry(el.width - 0.4, 0.06, 0.5), sm);
    s.position.set(0, 0, i * 0.8 - 2.4); s.receiveShadow = true; g.add(s);
  }
}

function buildStreetLamp(g: THREE.Group, el: MapElement) {
  const pm = new THREE.MeshStandardMaterial({ color: 0x71717a, metalness: 0.7, roughness: 0.3 });
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 3.5, 8), pm).translateY(1.75));
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1, 6), pm);
  arm.rotation.z = Math.PI / 2; arm.position.set(0.5, 3.5, 0); g.add(arm);
  g.add(new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 8), new THREE.MeshStandardMaterial({ color: 0xfef3c7, emissive: 0xfbbf24, emissiveIntensity: 0.5, roughness: 0.1, metalness: 0.6 })).translateY(3.6));
  const pl = new THREE.PointLight(0xfbbf24, 0.8, 12);
  pl.position.y = 3.6; pl.castShadow = true; pl.shadow.mapSize.set(256, 256); g.add(pl);
}

function buildBusStop(g: THREE.Group, el: MapElement) {
  const m = new THREE.MeshStandardMaterial({ color: hexToNum(el.color), roughness: 0.4, metalness: 0.3 });
  [-0.8, 0.8].forEach(dx => g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.8, 8), m).translateX(dx).translateY(1.4)));
  g.add(new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 1.2), m).translateY(2.8));
  g.add(new THREE.Mesh(new THREE.BoxGeometry(2, 1.6, 0.08), new THREE.MeshStandardMaterial({ color: 0x818cf8, roughness: 0.5 })).translateY(1.4).translateZ(-0.55));
  g.add(new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.1, 0.5), new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.8 })).translateY(0.8));
}

function buildBench(g: THREE.Group, el: MapElement) {
  const wm = new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.8 });
  const mt = new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.7, roughness: 0.3 });
  g.add(new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.08, 0.5), wm).translateY(0.5));
  const bk = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.6, 0.06), wm);
  bk.position.set(0, 0.85, -0.22); bk.rotation.x = -0.15; g.add(bk);
  [-0.6, 0.6].forEach(dx => g.add(new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.5, 0.4), mt).translateX(dx).translateY(0.25)));
}

function buildFountain(g: THREE.Group, el: MapElement) {
  const sm = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.5, metalness: 0.2 });
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.7, 0.5, 24), sm).translateY(0.25));
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.1, 24), new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.7, roughness: 0.1, metalness: 0.6 })).translateY(0.55));
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 1.5, 8), sm).translateY(1.2));
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.3, 0.3, 12), sm).translateY(2));
}

function buildPark(g: THREE.Group, el: MapElement) {
  g.add(new THREE.Mesh(new THREE.PlaneGeometry(el.width, el.depth), new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.95 })).rotateX(-Math.PI / 2));
}

function buildFlag(g: THREE.Group, el: MapElement) {
  const pm = new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.8, roughness: 0.2 });
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 5, 8), pm).translateY(2.5));
  g.add(new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1), new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.5, side: THREE.DoubleSide })).translateX(0.75).translateY(4.3));
  g.add(new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.9, roughness: 0.1 })).translateY(5.1));
}

function buildCharacter(g: THREE.Group, el: MapElement) {
  g.add(new THREE.Mesh(new THREE.CapsuleGeometry(0.35, 0.8, 8, 16), new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.4, metalness: 0.3 })).translateY(1.2));
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 16), new THREE.MeshStandardMaterial({ color: 0xfcd9b6, roughness: 0.6 }));
  head.position.y = 2; head.castShadow = true; g.add(head);
  [-0.1, 0.1].forEach(ex => g.add(new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.2, metalness: 0.8 })).translateX(ex).translateY(2.05).translateZ(0.27)));
  const cane = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.5, 6), new THREE.MeshStandardMaterial({ color: 0xfbbf24, roughness: 0.3, metalness: 0.6 }));
  cane.position.set(0.5, 0.6, 0.3); cane.rotation.z = -0.3; g.add(cane);
}
