"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";
import { MapElement, hexToNum } from "@/lib/mapData";

interface Props {
  elements: MapElement[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  transformMode: "translate" | "rotate" | "scale";
  onElementUpdate: (id: string, updates: Partial<MapElement>) => void;
  playMode: boolean;
  characterPos: { x: number; y: number; z: number };
  taskCompleted: boolean;
  onHoverObject: (name: string | null) => void;
  snapEnabled: boolean;
  snapValue: number;
}

export default function UE5Viewport({
  elements,
  selectedId,
  onSelect,
  transformMode,
  onElementUpdate,
  playMode,
  characterPos,
  taskCompleted,
  onHoverObject,
  snapEnabled,
  snapValue,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const orbitRef = useRef<OrbitControls | null>(null);
  const transformRef = useRef<TransformControls | null>(null);
  const clockRef = useRef(new THREE.Clock());

  const meshMapRef = useRef<Map<string, THREE.Object3D>>(new Map());
  const carGroupsRef = useRef<Map<string, THREE.Group>>(new Map());
  const trafficLightsRef = useRef<THREE.Mesh[]>([]);
  const characterGroupRef = useRef<THREE.Group | null>(null);
  const markerRef = useRef<THREE.Group | null>(null);

  const [fps, setFps] = useState(60);
  const lastKeyRef = useRef("");
  const animFrameRef = useRef(0);
  const buildKeyRef = useRef("");

  // ==================== BUILD SCENE ====================
  const buildScene = useCallback((scene: THREE.Scene, elements: MapElement[]) => {
    // Dynamic objeleri temizle
    const toRemove: THREE.Object3D[] = [];
    scene.traverse((obj) => {
      if (obj.userData._dynamic) toRemove.push(obj);
    });
    toRemove.forEach((o) => { o.parent?.remove(o); });
    
    meshMapRef.current.clear();
    carGroupsRef.current.clear();
    trafficLightsRef.current = [];

    const dyn = (obj: THREE.Object3D) => { obj.userData._dynamic = true; return obj; };

    // Ground
    if (!scene.userData._hasGround) {
      const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(120, 120),
        new THREE.MeshStandardMaterial({ color: 0x1b1b1b, roughness: 0.9, metalness: 0.1 })
      );
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);
      scene.userData._hasGround = true;

      // UE5-style Grid
      const gridHelper = new THREE.GridHelper(120, 120, 0x353535, 0x222222);
      gridHelper.position.y = 0.01;
      gridHelper.material.opacity = 0.4;
      gridHelper.material.transparent = true;
      scene.add(gridHelper);
    }

    elements.forEach((el) => {
      // Gizli ve editör/oyun karakteri ayrımı
      if (el.type === "character" && !playMode) return;

      const group = new THREE.Group();
      group.userData = { id: el.id, label: el.label, description: el.description, type: el.type, _dynamic: true };

      switch (el.type) {
        case "building": buildBuilding(group, el); break;
        case "road": buildRoad(group, el); break;
        case "tree": buildTree(group, el); break;
        case "car": buildCar(group, el); carGroupsRef.current.set(el.id, group); break;
        case "trafficLight": buildTrafficLight(group, el, trafficLightsRef); break;
        case "crosswalk": buildCrosswalk(group, el); break;
        case "streetLamp": buildStreetLamp(group, el); break;
        case "busStop": buildBusStop(group, el); break;
        case "bench": buildBench(group, el); break;
        case "fountain": buildFountain(group, el); break;
        case "park": buildPark(group, el); break;
        case "flag": buildFlag(group, el); break;
        case "character": buildCharacter(group, el); characterGroupRef.current = group; break;
      }

      group.position.set(el.x, el.y || 0, el.z);
      
      // Kaydedilmiş rotasyon varsa ata
      if (el.roadRotY && el.type === "road") group.rotation.y = el.roadRotY;
      else if (el.type === "car" && el.dirX === -1) group.rotation.y = Math.PI;

      // Ölçeklendirmeyi ata
      if (el.type === "tree" && el.scale) group.scale.set(el.scale, el.scale, el.scale);
      
      dyn(group);
      scene.add(group);
      meshMapRef.current.set(el.id, group);
    });

    // Task Marker (Play mode'da parıldayan halka)
    if (playMode) {
      const mg = new THREE.Group();
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(1.2, 0.05, 8, 24),
        new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 0.8, transparent: true, opacity: 0.8 })
      );
      ring.rotation.x = Math.PI / 2;
      mg.add(ring);
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.01, 0.05, 6, 16, 1, true),
        new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.15 })
      );
      beam.position.y = 3;
      mg.add(beam);
      
      markerRef.current = dyn(mg) as THREE.Group;
      scene.add(mg);
    } else {
      markerRef.current = null;
    }

  }, [playMode]);

  // ==================== INIT THREE ENGINE ====================
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    
    // Create Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x151515); // UE5 dark background
    scene.fog = new THREE.FogExp2(0x151515, 0.008);
    sceneRef.current = scene;

    // Create Camera
    const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 500);
    camera.position.set(30, 25, 40);
    cameraRef.current = camera;

    // Create Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Orbit Controls
    const orbit = new OrbitControls(camera, renderer.domElement);
    orbit.enableDamping = true;
    orbit.dampingFactor = 0.05;
    orbit.maxPolarAngle = Math.PI / 2.05; // Yere girmesini engelle
    orbit.minDistance = 5;
    orbit.maxDistance = 120;
    orbitRef.current = orbit;

    // Transform Controls (Gizmo)
    const transform = new TransformControls(camera, renderer.domElement);
    transform.setSize(0.8);
    transform.setSpace("world");
    scene.add(transform as any);
    transformRef.current = transform;

    // Gizmo Eventleri
    transform.addEventListener("dragging-changed", (event) => {
      orbit.enabled = !event.value; // Taşırken orbit kilitlensin
    });

    transform.addEventListener("change", () => {
      const target = transform.object;
      if (!target) return;
      const id = target.userData.id;
      if (!id) return;

      // Element modelini güncelle
      const updates: Partial<MapElement> = {
        x: Number(target.position.x.toFixed(2)),
        y: Number(target.position.y.toFixed(2)),
        z: Number(target.position.z.toFixed(2)),
      };

      if (transformMode === "rotate") {
        updates.roadRotY = Number(target.rotation.y.toFixed(3));
      } else if (transformMode === "scale") {
        updates.scale = Number(target.scale.x.toFixed(2));
        updates.width = Number((target.scale.x * 5).toFixed(2)); // basic scale map
      }

      onElementUpdate(id, updates);
    });

    // Aydınlatma
    const amb = new THREE.AmbientLight(0xddddff, 0.4);
    scene.add(amb);

    // Ana Güneş Işığı
    const sun = new THREE.DirectionalLight(0xfff5ea, 1.8);
    sun.position.set(40, 60, 20);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.near = 0.5;
    sun.shadow.camera.far = 150;
    sun.shadow.camera.left = sun.shadow.camera.bottom = -50;
    sun.shadow.camera.right = sun.shadow.camera.top = 50;
    sun.shadow.bias = -0.0002;
    scene.add(sun);

    const fill = new THREE.DirectionalLight(0x88bbff, 0.4);
    fill.position.set(-20, 20, -20);
    scene.add(fill);

    const hemi = new THREE.HemisphereLight(0xffffff, 0x444455, 0.2);
    scene.add(hemi);

    // Sky Dome
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(150, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0x0a0a10, side: THREE.BackSide })
    );
    scene.add(sky);

    // İlk sahneyi oluştur
    buildScene(scene, elements);

    // ==================== RAYCASTER & INTERACTION ====================
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onPointerDown = (e: PointerEvent) => {
      if (playMode) return; // Play modda nesne seçimi yok
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(scene.children, true);
      
      if (hits.length > 0) {
        // TransformControls mesh'ine tıkladıysa iptal et (seçimi bozma)
        let clickedGizmo = false;
        hits.forEach(h => {
          let p = h.object.parent;
          while(p) {
            if (p instanceof TransformControls) clickedGizmo = true;
            p = p.parent;
          }
        });
        if (clickedGizmo) return;

        // Üst hiyerarşide map elementini ara
        let clickedElementObj: THREE.Object3D | null = null;
        for (const hit of hits) {
          let p: THREE.Object3D | null = hit.object;
          while (p && p !== scene) {
            if (p.userData && p.userData.id) {
              clickedElementObj = p;
              break;
            }
            p = p.parent;
          }
          if (clickedElementObj) break;
        }

        if (clickedElementObj) {
          onSelect(clickedElementObj.userData.id);
          return;
        }
      }
      
      // Boşluğa tıkladıysa
      // Ama sürükleme yaptıysa iptal etme
      if (e.pointerType === "mouse" && e.button !== 0) return; // Sadece sol tık
      setTimeout(() => {
        if (orbit.enabled) { // sürükleme bitiminde transform dragging-changed tetiklenmemişse
          // onSelect(null); // kapatıldı ki outliner tıklamaları çakışmasın
        }
      }, 10);
    };

    const onMouseMove = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(scene.children, true).filter(h => h.object.userData._dynamic || (h.object.parent?.userData && h.object.parent.userData._dynamic));
      
      if (hits.length > 0) {
        let label = hits[0].object.userData.label || hits[0].object.parent?.userData.label;
        onHoverObject(label || null);
      } else {
        onHoverObject(null);
      }
    };

    renderer.domElement.addEventListener("pointerdown", onPointerDown);
    renderer.domElement.addEventListener("mousemove", onMouseMove);

    // FPS counter
    let frames = 0;
    let lastTime = performance.now();

    // ==================== ANIMASYON LOOPU ====================
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      const delta = clockRef.current.getDelta();
      const elapsed = clockRef.current.getElapsedTime();

      // FPS hesabı
      frames++;
      const time = performance.now();
      if (time >= lastTime + 1000) {
        setFps(Math.round((frames * 1000) / (time - lastTime)));
        frames = 0;
        lastTime = time;
      }

      // Trafik ışıkları
      const tl = _trafficLightMeshes;
      if (tl.length >= 6) {
        const ci = Math.floor(elapsed * 0.4) % 3;
        tl.forEach((m, i) => {
          const gi = Math.floor(i / 3);
          const li = i % 3;
          (m.material as THREE.MeshStandardMaterial).emissiveIntensity = li === (ci + gi) % 3 ? 1.5 : 0.05;
        });
      }

      // Arabalar
      carGroupsRef.current.forEach((cg, id) => {
        const el = elements.find((e) => e.id === id);
        if (!el) return;
        const d = el.dirX || 1;
        const s = el.speed || 3;
        cg.position.x += d * s * delta;
        if (cg.position.x > 40) cg.position.x = -40;
        if (cg.position.x < -40) cg.position.x = 40;
      });

      // Play mod markerı
      if (markerRef.current) {
        markerRef.current.children[0].rotation.z = elapsed * 0.6;
        markerRef.current.children[1].scale.y = 0.8 + Math.sin(elapsed * 4) * 0.2;
        
        const mc = taskCompleted ? 0x22c55e : 0x00aaff;
        (markerRef.current.children[0] as THREE.Mesh).material = new THREE.MeshStandardMaterial({
          color: mc, emissive: mc, emissiveIntensity: 1.0, transparent: true, opacity: 0.8
        });
      }

      // Karakter lerp (Play mod)
      if (playMode && characterGroupRef.current) {
        characterGroupRef.current.position.lerp(new THREE.Vector3(characterPos.x, characterPos.y, characterPos.z), 0.12);
        if (markerRef.current) {
          markerRef.current.position.lerp(new THREE.Vector3(characterPos.x, characterPos.y, characterPos.z), 0.12);
        }

        // Kameranın karakteri takip etmesi
        if (orbit.target) {
          orbit.target.lerp(characterGroupRef.current.position, 0.1);
          camera.position.add(
            new THREE.Vector3(characterPos.x, characterPos.y, characterPos.z)
              .sub(characterGroupRef.current.position)
          );
        }
      }

      orbit.update();
      renderer.render(scene, camera);
    };
    
    animate();

    // Resize
    const handleResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      renderer.domElement.removeEventListener("pointerdown", onPointerDown);
      renderer.domElement.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, [buildScene]); // Mount olunca bir kere çalışır

  // Elements veya PlayMode değiştikçe sahneyi baştan kur
  useEffect(() => {
    if (!sceneRef.current) return;
    const key = JSON.stringify(elements.map(e => ({ id: e.id, x: e.x, y: e.y, z: e.z, w: e.width, h: e.height, d: e.depth, fl: e.floors, rt: e.roofType, sc: e.scale, c: e.color })));
    if (key !== buildKeyRef.current) {
      buildKeyRef.current = key;
      buildScene(sceneRef.current, elements);
    }
  }, [elements, buildScene]);

  // Gizmo Modu & Hedef Seçimi
  useEffect(() => {
    const transform = transformRef.current;
    if (!transform || !sceneRef.current) return;

    if (playMode || !selectedId) {
      transform.detach();
      return;
    }

    const obj = meshMapRef.current.get(selectedId);
    if (obj) {
      transform.setMode(transformMode);
      
      // Snap ayarları
      if (snapEnabled) {
        transform.setTranslationSnap(snapValue);
        transform.setRotationSnap(THREE.MathUtils.degToRad(snapValue * 15));
        transform.setScaleSnap(0.1);
      } else {
        transform.setTranslationSnap(null);
        transform.setRotationSnap(null);
        transform.setScaleSnap(null);
      }

      transform.attach(obj);
    } else {
      transform.detach();
    }
  }, [selectedId, transformMode, snapEnabled, snapValue, playMode, elements]);

  // Klavye kısayolları (W, E, R)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (key === "w") onElementUpdate("__mode", { label: "translate" } as any);
      if (key === "e") onElementUpdate("__mode", { label: "rotate" } as any);
      if (key === "r") onElementUpdate("__mode", { label: "scale" } as any);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onElementUpdate]);

  return (
    <div className="relative w-full h-full" ref={containerRef}>
      {/* UE5 Overlay UI */}
      <div className="absolute top-2 left-2 flex items-center gap-4 bg-[#1b1b1b]/80 border border-[#333]/50 px-3 py-1.5 rounded text-[10px] font-mono text-slate-400 z-20 pointer-events-none">
        <div>FPS: <span className={fps > 50 ? "text-green-500" : "text-yellow-500"}>{fps}</span></div>
        <div>VERTICES: <span className="text-white">{(elements.length * 120).toLocaleString()}</span></div>
        <div>MODE: <span className="text-sky-400 uppercase">{playMode ? "PIE" : "EDITOR"}</span></div>
      </div>
    </div>
  );
}

// ===================================================================
// 3D MESH BUILDER FUNCTIONS (UE5 TARZI YÜKSEK DETAY)
// ===================================================================

const _trafficLightMeshes: THREE.Mesh[] = [];

function buildBuilding(g: THREE.Group, el: MapElement) {
  const w = el.width, h = el.height, d = el.depth, color = hexToNum(el.color);
  const floors = el.floors || 1;
  const darker = new THREE.Color(color).multiplyScalar(0.6);
  const lighter = new THREE.Color(color).multiplyScalar(1.2);

  // Concrete Base
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.8 });
  const base = new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, 0.1, d + 0.1), baseMat);
  base.position.y = 0.05;
  base.receiveShadow = true;
  g.add(base);

  // Main Mesh
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshStandardMaterial({
      color,
      roughness: 0.6,
      metalness: 0.1,
    })
  );
  body.position.y = h / 2 + 0.1;
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  // Windows
  const winMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xfef3c7,
    emissiveIntensity: 0.4,
    roughness: 0.1,
    metalness: 0.8,
  });
  const darkWinMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.8 });

  const rows = floors;
  const cols = Math.max(2, Math.floor(w / 1.5));
  const floorH = h / rows;

  for (let f = 0; f < 4; f++) {
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const win = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, 0.04), (r + c) % 3 !== 0 ? winMat : darkWinMat);
        const wx = -w / 2 + 0.8 + c * ((w - 1.6) / cols);
        const wy = 0.1 + r * floorH + floorH / 2;
        const wz = d / 2 + 0.03;

        if (f === 0) win.position.set(wx, wy, wz);
        else if (f === 1) win.position.set(wx, wy, -wz);
        else if (f === 2) { win.rotation.y = Math.PI / 2; win.position.set(wz, wy, wx); }
        else { win.rotation.y = Math.PI / 2; win.position.set(-wz, wy, wx); }
        
        g.add(win);
      }
    }
  }

  // Door
  const door = new THREE.Mesh(new THREE.BoxGeometry(1, 1.8, 0.08), new THREE.MeshStandardMaterial({ color: darker, roughness: 0.5 }));
  door.position.set(0, 1, d / 2 + 0.04);
  door.castShadow = true;
  g.add(door);

  // Roof
  const rt = el.roofType || "flat";
  if (rt === "pointed") {
    const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.6, 2.5, 4), new THREE.MeshStandardMaterial({ color: 0x3b2a56, roughness: 0.4 }));
    roof.position.y = h + 1.25 + 0.1;
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    g.add(roof);
  } else if (rt === "dome") {
    const dome = new THREE.Mesh(new THREE.SphereGeometry(Math.min(w, d) * 0.45, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x065f46, roughness: 0.4 }));
    dome.position.y = h + 0.1;
    dome.castShadow = true;
    g.add(dome);

    // Minaret
    const min = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, h + 3, 8), new THREE.MeshStandardMaterial({ color: 0x0d9488 }));
    min.position.set(w / 2 + 0.6, (h + 3) / 2, 0);
    min.castShadow = true;
    g.add(min);
    
    const mt = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 8), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.8 }));
    mt.position.set(w / 2 + 0.6, h + 3.2, 0);
    g.add(mt);
  } else {
    // Parapet
    const para = new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, 0.3, d + 0.1), new THREE.MeshStandardMaterial({ color: lighter, roughness: 0.6 }));
    para.position.y = h + 0.15;
    para.castShadow = true;
    g.add(para);
  }
}

function buildRoad(g: THREE.Group, el: MapElement) {
  const w = el.width, d = el.depth;
  
  // Road surface
  const road = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.85, metalness: 0.1 }));
  road.rotation.x = -Math.PI / 2;
  road.position.y = 0.02;
  road.receiveShadow = true;
  g.add(road);

  // Yellow central dash lines
  const dashMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24, roughness: 0.6 });
  const isVert = el.width < el.depth;
  const len = isVert ? d : w;

  for (let i = -Math.floor(len / 4); i <= Math.floor(len / 4); i++) {
    const dash = new THREE.Mesh(new THREE.PlaneGeometry(isVert ? 0.15 : 1.5, isVert ? 1.5 : 0.15), dashMat);
    dash.rotation.x = -Math.PI / 2;
    dash.position.y = 0.03;
    if (isVert) dash.position.set(0, 0.03, i * 4);
    else dash.position.set(i * 4, 0.03, 0);
    g.add(dash);
  }

  // Sidewalks
  const swMat = new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.7 });
  [-1, 1].forEach(s => {
    if (isVert) {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(w, 0.15, 1.5), swMat);
      sw.position.set(0, 0.075, (d / 2 + 0.75) * s);
      sw.receiveShadow = true; g.add(sw);
    } else {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.15, d), swMat);
      sw.position.set((w / 2 + 0.75) * s, 0.075, 0);
      sw.receiveShadow = true; g.add(sw);
    }
  });
}

function buildTree(g: THREE.Group, el: MapElement) {
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 1.8, 8), new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 }));
  trunk.position.y = 0.9;
  trunk.castShadow = true;
  g.add(trunk);

  const leafMat = new THREE.MeshStandardMaterial({ color: 0x1e5c2b, roughness: 0.8 });
  [1.4, 1.0, 0.7].forEach((r, i) => {
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(r, 8, 8), leafMat);
    leaf.position.y = 1.6 + i * 0.6;
    leaf.castShadow = true;
    g.add(leaf);
  });
}

function buildCar(g: THREE.Group, el: MapElement) {
  const color = hexToNum(el.carColor || el.color || "#3b82f6");
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.2, metalness: 0.6 });

  // Base body
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.6, 1.1), mat);
  body.position.y = 0.45;
  body.castShadow = true;
  g.add(body);

  // Cockpit
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.1, metalness: 0.8, transparent: true, opacity: 0.6 });
  const cab = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.5, 1.0), glassMat);
  cab.position.set(-0.1, 1.0, 0);
  cab.castShadow = true;
  g.add(cab);

  // Wheels
  const wm = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
  [[-0.6, 0.55], [0.6, 0.55], [-0.6, -0.55], [0.6, -0.55]].forEach(([wx, wz]) => {
    const w = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.15, 16), wm);
    w.rotation.z = Math.PI / 2;
    w.position.set(wx, 0.22, wz);
    w.castShadow = true;
    g.add(w);
  });
}

function buildTrafficLight(g: THREE.Group, el: MapElement, lightsArrayRef: React.MutableRefObject<THREE.Mesh[]>) {
  const pm = new THREE.MeshStandardMaterial({ color: 0x333333, metalness: 0.6, roughness: 0.3 });
  
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 4, 8), pm);
  pole.position.y = 2; pole.castShadow = true; g.add(pole);

  const box = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.5, 0.4), pm);
  box.position.y = 4.25; box.castShadow = true; g.add(box);

  [0x22c55e, 0xeab308, 0xef4444].forEach((c, i) => {
    const l = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 12), new THREE.MeshStandardMaterial({
      color: c, emissive: c, emissiveIntensity: 0, roughness: 0.1, metalness: 0.8
    }));
    l.position.set(0, 4.6 - i * 0.4, 0.2);
    l.userData._lightIdx = i;
    g.add(l);
    lightsArrayRef.current.push(l);
  });
}

function buildCrosswalk(g: THREE.Group, el: MapElement) {
  const m = new THREE.MeshStandardMaterial({ color: 0xcccccc, roughness: 0.4 });
  for (let i = 0; i < 6; i++) {
    const s = new THREE.Mesh(new THREE.BoxGeometry(el.width - 0.2, 0.05, 0.4), m);
    s.position.set(0, 0, i * 0.7 - 1.75);
    s.receiveShadow = true;
    g.add(s);
  }
}

function buildStreetLamp(g: THREE.Group, el: MapElement) {
  const pm = new THREE.MeshStandardMaterial({ color: 0x444444, metalness: 0.8, roughness: 0.2 });
  
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 3.5, 8), pm).translateY(1.75));
  
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1, 6), pm);
  arm.rotation.z = Math.PI / 2;
  arm.position.set(0.5, 3.5, 0);
  g.add(arm);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 12, 12),
    new THREE.MeshStandardMaterial({ color: 0xffffee, emissive: 0xffd700, emissiveIntensity: 0.6, roughness: 0.1 })
  );
  head.position.set(1.0, 3.5, 0);
  g.add(head);

  const l = new THREE.PointLight(0xffaa44, 1.2, 12);
  l.position.set(1.0, 3.5, 0);
  l.castShadow = true;
  l.shadow.mapSize.set(512, 512);
  g.add(l);
}

function buildBusStop(g: THREE.Group, el: MapElement) {
  const m = new THREE.MeshStandardMaterial({ color: hexToNum(el.color), roughness: 0.4, metalness: 0.4 });
  
  // Frame
  const p1 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.6, 8), m);
  p1.position.set(-1.0, 1.3, -0.4); g.add(p1);
  const p2 = p1.clone(); p2.position.x = 1.0; g.add(p2);
  const p3 = p1.clone(); p3.position.z = 0.4; g.add(p3);
  const p4 = p2.clone(); p4.position.z = 0.4; g.add(p4);

  // Glass panels
  const gm = new THREE.MeshStandardMaterial({ color: 0x88ccff, transparent: true, opacity: 0.4, roughness: 0.1 });
  const panel = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2, 0.04), gm);
  panel.position.set(0, 1.3, -0.4);
  g.add(panel);

  // Roof
  const roof = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.08, 1.2), m);
  roof.position.y = 2.6; roof.castShadow = true; g.add(roof);

  // Bench
  const bench = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.06, 0.4), new THREE.MeshStandardMaterial({ color: 0x4a2c11, roughness: 0.8 }));
  bench.position.set(0, 0.7, 0);
  g.add(bench);
}

function buildBench(g: THREE.Group, el: MapElement) {
  const m = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.4 });
  const seat = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.06, 0.4), new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.8 }));
  seat.position.y = 0.4; seat.castShadow = true; g.add(seat);

  const back = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.4, 0.05), new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.8 }));
  back.position.set(0, 0.7, -0.18); back.rotation.x = -0.1; back.castShadow = true; g.add(back);

  [-0.6, 0.6].forEach(dx => {
    const l = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.4, 0.35), m);
    l.position.set(dx, 0.2, 0); g.add(l);
  });
}

function buildFountain(g: THREE.Group, el: MapElement) {
  const sm = new THREE.MeshStandardMaterial({ color: 0x777777, roughness: 0.6 });
  
  const b = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.8, 0.4, 16), sm);
  b.position.y = 0.2; b.castShadow = true; b.receiveShadow = true; g.add(b);

  const wm = new THREE.MeshStandardMaterial({ color: 0x44aacc, transparent: true, opacity: 0.8, roughness: 0.1 });
  const w = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.08, 16), wm);
  w.position.y = 0.4; g.add(w);

  const pil = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 1.2, 8), sm);
  pil.position.y = 1.0; pil.castShadow = true; g.add(pil);

  const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.3, 0.2, 12), sm);
  bowl.position.y = 1.6; g.add(bowl);
}

function buildPark(g: THREE.Group, el: MapElement) {
  const p = new THREE.Mesh(new THREE.PlaneGeometry(el.width, el.depth), new THREE.MeshStandardMaterial({ color: 0x2e5a27, roughness: 0.9 }));
  p.rotation.x = -Math.PI / 2; p.position.y = 0.01; p.receiveShadow = true; g.add(p);
}

function buildFlag(g: THREE.Group, el: MapElement) {
  const pm = new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.8 });
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.06, 4.5, 8), pm).translateY(2.25));

  const flag = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.8),
    new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5, side: THREE.DoubleSide })
  );
  flag.position.set(0.6, 3.8, 0);
  flag.castShadow = true;
  g.add(flag);

  g.add(new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.8 })).translateY(4.55));
}

function buildCharacter(g: THREE.Group, el: MapElement) {
  const pm = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.3, 0.6, 8, 16), pm);
  body.position.y = 0.9; body.castShadow = true; g.add(body);

  const hm = new THREE.MeshStandardMaterial({ color: 0xffdbac, roughness: 0.6 });
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 16), hm);
  head.position.y = 1.5; head.castShadow = true; g.add(head);

  const em = new THREE.MeshStandardMaterial({ color: 0x111111 });
  [-0.08, 0.08].forEach(x => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), em);
    eye.position.set(x, 1.55, 0.22);
    g.add(eye);
  });

  const cane = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.2, 6), new THREE.MeshStandardMaterial({ color: 0xdddddd, roughness: 0.2 }));
  cane.position.set(0.35, 0.5, 0.3); cane.rotation.z = -0.2; cane.castShadow = true; g.add(cane);

  // Parıltı
  const glow = new THREE.Mesh(
    new THREE.TorusGeometry(0.4, 0.02, 8, 24),
    new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.5 })
  );
  glow.rotation.x = Math.PI / 2; glow.position.y = 0.02; g.add(glow);
}
