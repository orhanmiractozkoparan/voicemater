"use client";

import { useState } from "react";

interface Task {
  id: number;
  title: string;
  description: string;
  difficulty: "Kolay" | "Orta" | "Zor";
  hint: string;
  icon: string;
  completed: boolean;
  steps?: string[];
  reward?: string;
  characterX: number;
  characterY: number;
}

interface TaskCreatorProps {
  tasks: Task[];
  onTasksUpdate: (tasks: Task[]) => void;
  onBack: () => void;
  onSpeak: (text: string, options?: any) => void;
}

const ICONS = ["🦓", "🚦", "🏫", "🏥", "🌳", "🔄", "🚌", "🛒", "☪", "🏁", "🚗", "🏠", "💊", "☕", "📚", "⛲", "🏛️", "🏗️", "🎪", "🎭"];

const DIFFICULTY_OPTIONS: ("Kolay" | "Orta" | "Zor")[] = ["Kolay", "Orta", "Zor"];

export function TaskCreator({ tasks, onTasksUpdate, onBack, onSpeak }: TaskCreatorProps) {
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    difficulty: "Kolay" as "Kolay" | "Orta" | "Zor",
    hint: "",
    icon: "📍",
    steps: [""],
    reward: "",
    characterX: 400,
    characterY: 300,
  });

  const handleCreateNew = () => {
    setEditingTask(null);
    setFormData({
      title: "",
      description: "",
      difficulty: "Kolay",
      hint: "",
      icon: "📍",
      steps: ["Yola çık", "Hedefe ulaş"],
      reward: "",
      characterX: 100 + Math.random() * 700,
      characterY: 100 + Math.random() * 400,
    });
    setShowForm(true);
    onSpeak("Yeni görev oluşturma ekranı. Görev bilgilerini doldurun.", { rate: 0.85 });
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setFormData({
      title: task.title,
      description: task.description,
      difficulty: task.difficulty,
      hint: task.hint,
      icon: task.icon,
      steps: task.steps && task.steps.length > 0 ? [...task.steps] : [""],
      reward: task.reward || "",
      characterX: task.characterX,
      characterY: task.characterY,
    });
    setShowForm(true);
    onSpeak(`${task.id}. görev düzenleniyor.`, { rate: 0.85 });
  };

  const handleSave = () => {
    if (!formData.title.trim() || !formData.description.trim()) {
      onSpeak("Lütfen görev başlığı ve açıklamasını girin!", { rate: 0.85 });
      return;
    }

    if (editingTask) {
      // Edit existing
      const updated = tasks.map(t =>
        t.id === editingTask.id
          ? {
              ...t,
              title: formData.title,
              description: formData.description,
              difficulty: formData.difficulty,
              hint: formData.hint,
              icon: formData.icon,
              steps: formData.steps.filter(s => s.trim()),
              reward: formData.reward,
              characterX: formData.characterX,
              characterY: formData.characterY,
            }
          : t
      );
      onTasksUpdate(updated);
      onSpeak(`${editingTask.id}. görev güncellendi.`, { rate: 0.85 });
    } else {
      // Create new
      const maxId = Math.max(0, ...tasks.map(t => t.id));
      const newTask: Task = {
        id: maxId + 1,
        title: formData.title,
        description: formData.description,
        difficulty: formData.difficulty,
        hint: formData.hint,
        icon: formData.icon,
        completed: false,
        steps: formData.steps.filter(s => s.trim()),
        reward: formData.reward,
        characterX: formData.characterX,
        characterY: formData.characterY,
      };
      onTasksUpdate([...tasks, newTask]);
      onSpeak(`Yeni görev oluşturuldu: ${formData.title}`, { rate: 0.85 });
    }

    setShowForm(false);
    setEditingTask(null);
  };

  const handleDelete = (taskId: number) => {
    if (tasks.length <= 1) {
      onSpeak("En az bir görev olmalı!", { rate: 0.85 });
      return;
    }
    const updated = tasks.filter(t => t.id !== taskId).map((t, i) => ({ ...t, id: i + 1 }));
    onTasksUpdate(updated);
    onSpeak("Görev silindi.", { rate: 0.85 });
  };

  const addStep = () => {
    setFormData(prev => ({ ...prev, steps: [...prev.steps, ""] }));
  };

  const updateStep = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      steps: prev.steps.map((s, i) => (i === index ? value : s)),
    }));
  };

  const removeStep = (index: number) => {
    if (formData.steps.length <= 1) return;
    setFormData(prev => ({ ...prev, steps: prev.steps.filter((_, i) => i !== index) }));
  };

  const handleMoveTask = (taskId: number, direction: "up" | "down") => {
    const idx = tasks.findIndex(t => t.id === taskId);
    if (direction === "up" && idx > 0) {
      const newTasks = [...tasks];
      [newTasks[idx - 1], newTasks[idx]] = [newTasks[idx], newTasks[idx - 1]];
      const reindexed = newTasks.map((t, i) => ({ ...t, id: i + 1 }));
      onTasksUpdate(reindexed);
    } else if (direction === "down" && idx < tasks.length - 1) {
      const newTasks = [...tasks];
      [newTasks[idx], newTasks[idx + 1]] = [newTasks[idx + 1], newTasks[idx]];
      const reindexed = newTasks.map((t, i) => ({ ...t, id: i + 1 }));
      onTasksUpdate(reindexed);
    }
  };

  if (showForm) {
    const diffConfig = {
      Kolay: { color: "text-green-400 bg-green-500/10 border-green-500/30" },
      Orta: { color: "text-amber-400 bg-amber-500/10 border-amber-500/30" },
      Zor: { color: "text-red-400 bg-red-500/10 border-red-500/30" },
    };

    return (
      <div className="w-full max-w-3xl mx-auto px-4">
        {/* Form Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            className="voice-btn px-4 py-2 glass rounded-xl text-white hover:bg-slate-600/50 flex items-center gap-2"
            onClick={() => { setShowForm(false); setEditingTask(null); }}
          >
            ← Geri
          </button>
          <h2 className="text-xl font-bold text-white">
            {editingTask ? `✏️ Görev ${editingTask.id} Düzenle` : "🆕 Yeni Görev Oluştur"}
          </h2>
          <button
            className="voice-btn px-4 py-2 bg-green-600 rounded-xl text-white hover:bg-green-500 font-semibold flex items-center gap-2"
            onClick={handleSave}
          >
            💾 Kaydet
          </button>
        </div>

        {/* Form Card */}
        <div className="glass-card rounded-3xl p-8 space-y-6">
          {/* Icon Selector */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">🎯 Görev İkonu</label>
            <div className="flex flex-wrap gap-2">
              {ICONS.map(icon => (
                <button
                  key={icon}
                  className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl transition-all ${
                    formData.icon === icon
                      ? "bg-sky-500/30 border-2 border-sky-400 scale-110"
                      : "glass-light hover:bg-slate-600/50 border border-transparent"
                  }`}
                  onClick={() => setFormData(prev => ({ ...prev, icon }))}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">📝 Görev Başlığı</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Örn: Yaya Geçidinden Geç"
              className="w-full px-4 py-3 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/50 transition-all"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">📄 Görev Açıklaması</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Görevin detaylı açıklamasını yazın..."
              rows={3}
              className="w-full px-4 py-3 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/50 transition-all resize-none"
            />
          </div>

          {/* Difficulty */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">⚡ Zorluk Seviyesi</label>
            <div className="flex gap-3">
              {DIFFICULTY_OPTIONS.map(d => (
                <button
                  key={d}
                  className={`flex-1 py-3 rounded-xl font-semibold text-sm border transition-all ${
                    formData.difficulty === d
                      ? diffConfig[d].color
                      : "glass-light text-slate-400 border-slate-600/30 hover:bg-slate-600/50"
                  }`}
                  onClick={() => setFormData(prev => ({ ...prev, difficulty: d }))}
                >
                  {d === "Kolay" ? "🟢" : d === "Orta" ? "🟡" : "🔴"} {d}
                </button>
              ))}
            </div>
          </div>

          {/* Hint */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">💡 İpucu</label>
            <textarea
              value={formData.hint}
              onChange={(e) => setFormData(prev => ({ ...prev, hint: e.target.value }))}
              placeholder="Oyuncuya yardımcı olacak ipucu yazın..."
              rows={2}
              className="w-full px-4 py-3 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/50 transition-all resize-none"
            />
          </div>

          {/* Steps */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-300">📝 Görev Adımları</label>
              <button
                className="text-xs px-3 py-1 bg-sky-500/20 text-sky-400 rounded-lg hover:bg-sky-500/30 transition-all"
                onClick={addStep}
              >
                + Adım Ekle
              </button>
            </div>
            <div className="space-y-2">
              {formData.steps.map((step, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center text-xs font-bold flex-shrink-0">
                    {i + 1}
                  </span>
                  <input
                    type="text"
                    value={step}
                    onChange={(e) => updateStep(i, e.target.value)}
                    placeholder={`Adım ${i + 1}`}
                    className="flex-1 px-3 py-2 bg-slate-800/50 border border-slate-600/50 rounded-lg text-white text-sm placeholder-slate-500 focus:outline-none focus:border-sky-400 transition-all"
                  />
                  <button
                    className="w-7 h-7 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 flex items-center justify-center text-sm transition-all"
                    onClick={() => removeStep(i)}
                    aria-label={`Adım ${i + 1} sil`}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Reward */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">🎁 Ödül (isteğe bağlı)</label>
            <input
              type="text"
              value={formData.reward}
              onChange={(e) => setFormData(prev => ({ ...prev, reward: e.target.value }))}
              placeholder="Örn: +100 puan, Rozet kazan"
              className="w-full px-4 py-3 bg-slate-800/50 border border-slate-600/50 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/50 transition-all"
            />
          </div>

          {/* Character Position */}
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">📍 Haritadaki Konum</label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-slate-500 mb-1 block">X Koordinatı: {formData.characterX}</label>
                <input
                  type="range"
                  min={30}
                  max={870}
                  value={formData.characterX}
                  onChange={(e) => setFormData(prev => ({ ...prev, characterX: parseInt(e.target.value) }))}
                  className="w-full accent-sky-400"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Y Koordinatı: {formData.characterY}</label>
                <input
                  type="range"
                  min={30}
                  max={570}
                  value={formData.characterY}
                  onChange={(e) => setFormData(prev => ({ ...prev, characterY: parseInt(e.target.value) }))}
                  className="w-full accent-sky-400"
                />
              </div>
            </div>
            <div className="mt-2 relative w-full h-24 bg-slate-800/50 rounded-xl border border-slate-600/30 overflow-hidden">
              <div
                className="absolute w-6 h-6 rounded-full bg-sky-400 border-2 border-white shadow-lg transition-all duration-300"
                style={{ left: `${(formData.characterX / 900) * 100}%`, top: `${(formData.characterY / 600) * 100}%`, transform: "translate(-50%, -50%)" }}
              />
              <div className="absolute bottom-1 right-2 text-[10px] text-slate-500">
                X:{formData.characterX} Y:{formData.characterY}
              </div>
            </div>
          </div>

          {/* Save / Cancel */}
          <div className="flex gap-3 pt-2">
            <button
              className="flex-1 voice-btn py-3 bg-green-600 text-white font-bold rounded-xl hover:bg-green-500 text-lg"
              onClick={handleSave}
            >
              💾 {editingTask ? "Güncelle" : "Oluştur"}
            </button>
            <button
              className="voice-btn py-3 px-6 bg-slate-700 text-white font-bold rounded-xl hover:bg-slate-600"
              onClick={() => { setShowForm(false); setEditingTask(null); }}
            >
              İptal
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Task List View
  return (
    <div className="w-full max-w-4xl mx-auto px-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          className="voice-btn px-4 py-2 glass rounded-xl text-white hover:bg-slate-600/50 flex items-center gap-2"
          onClick={onBack}
        >
          ← Ana Menü
        </button>
        <h2 className="text-2xl font-black shimmer-text">🛠️ Görev Tasarlama Ekranı</h2>
        <button
          className="voice-btn px-5 py-2.5 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-xl hover:from-green-400 hover:to-emerald-500 flex items-center gap-2 shadow-lg shadow-green-500/20"
          onClick={handleCreateNew}
        >
          ➕ Yeni Görev
        </button>
      </div>

      {/* Task Count */}
      <div className="glass rounded-2xl px-5 py-3 mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-xl">📋</span>
          <span className="text-sm text-slate-300">
            Toplam <span className="text-white font-bold">{tasks.length}</span> görev var
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <span className="text-green-400">🟢 {tasks.filter(t => t.difficulty === "Kolay").length} Kolay</span>
          <span className="text-amber-400">🟡 {tasks.filter(t => t.difficulty === "Orta").length} Orta</span>
          <span className="text-red-400">🔴 {tasks.filter(t => t.difficulty === "Zor").length} Zor</span>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-3">
        {tasks.map((task, index) => (
          <div
            key={task.id}
            className="glass-card rounded-2xl p-4 flex items-center gap-4 hover:border-sky-400/30 transition-all group"
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            {/* Task number */}
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center text-lg font-black border border-sky-500/20 flex-shrink-0">
              {task.id}
            </div>

            {/* Icon */}
            <div className="text-3xl flex-shrink-0">{task.icon}</div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-base font-bold text-white truncate">{task.title}</h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  task.difficulty === "Kolay" ? "bg-green-500/10 text-green-400 border border-green-500/20"
                  : task.difficulty === "Orta" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                  : "bg-red-500/10 text-red-400 border border-red-500/20"
                }`}>
                  {task.difficulty}
                </span>
                {task.steps && task.steps.length > 0 && (
                  <span className="text-[10px] text-slate-500">{task.steps.length} adım</span>
                )}
              </div>
              <p className="text-xs text-slate-400 truncate">{task.description}</p>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
              <button
                className="w-8 h-8 rounded-lg bg-slate-600/30 text-slate-400 hover:text-white hover:bg-slate-600/50 flex items-center justify-center text-sm transition-all"
                onClick={() => handleMoveTask(task.id, "up")}
                disabled={index === 0}
                aria-label="Yukarı taşı"
              >
                ↑
              </button>
              <button
                className="w-8 h-8 rounded-lg bg-slate-600/30 text-slate-400 hover:text-white hover:bg-slate-600/50 flex items-center justify-center text-sm transition-all"
                onClick={() => handleMoveTask(task.id, "down")}
                disabled={index === tasks.length - 1}
                aria-label="Aşağı taşı"
              >
                ↓
              </button>
              <button
                className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 hover:bg-sky-500/20 flex items-center justify-center text-sm transition-all"
                onClick={() => handleEditTask(task)}
                aria-label="Düzenle"
              >
                ✏️
              </button>
              <button
                className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 flex items-center justify-center text-sm transition-all"
                onClick={() => handleDelete(task.id)}
                aria-label="Sil"
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {tasks.length === 0 && (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">📭</div>
          <h3 className="text-xl font-bold text-white mb-2">Henüz görev yok</h3>
          <p className="text-slate-400 mb-6">Yeni bir görev oluşturarak başlayın</p>
          <button
            className="voice-btn px-8 py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold rounded-2xl"
            onClick={handleCreateNew}
          >
            ➕ İlk Görevi Oluştur
          </button>
        </div>
      )}
    </div>
  );
}
