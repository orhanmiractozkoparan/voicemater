"use client";

// ===================================================================
// HARİTA VERİ MODELİ
// Haritadaki HER şey bu veri yapısıyla tanımlanır.
// Kullanıcı bunları editörden ekleyebilir, silebilir, değiştirebilir.
// ===================================================================

export type ElementType =
  | "building"
  | "road"
  | "tree"
  | "car"
  | "trafficLight"
  | "crosswalk"
  | "streetLamp"
  | "busStop"
  | "bench"
  | "fountain"
  | "park"
  | "flag"
  | "character";

export interface MapElement {
  id: string;
  type: ElementType;
  label: string;
  description: string;
  x: number;
  y: number;
  z: number;
  width: number;
  height: number;
  depth: number;
  color: string;
  // Building specific
  floors?: number;
  roofType?: "flat" | "pointed" | "dome";
  // Road specific
  roadRotY?: number;
  // Tree specific
  scale?: number;
  // Car specific
  carColor?: string;
  dirX?: number;
  speed?: number;
  // Interactive
  interactive?: boolean;
  // task link
  taskId?: number;
}

export const ELEMENT_TEMPLATES: Record<ElementType, { label: string; icon: string; color: string; width: number; height: number; depth: number }> = {
  building:     { label: "Bina",         icon: "🏢", color: "#7c3aed", width: 5, height: 6, depth: 4 },
  road:         { label: "Yol",          icon: "🛣️", color: "#333333", width: 50, height: 0, depth: 8 },
  tree:         { label: "Ağaç",         icon: "🌳", color: "#22c55e", width: 1, height: 4, depth: 1 },
  car:          { label: "Araba",        icon: "🚗", color: "#3b82f6", width: 2, height: 1, depth: 1 },
  trafficLight: { label: "Trafik Işığı", icon: "🚦", color: "#555555", width: 0.6, height: 5, depth: 0.6 },
  crosswalk:    { label: "Yaya Geçidi",  icon: "🦓", color: "#ffffff", width: 6, height: 0, depth: 4 },
  streetLamp:   { label: "Sokak Lambası",icon: "💡", color: "#fbbf24", width: 0.5, height: 4, depth: 0.5 },
  busStop:      { label: "Otobüs Durağı",icon: "🚌", color: "#6366f1", width: 2.2, height: 3, depth: 1.2 },
  bench:        { label: "Bank",         icon: "🪑", color: "#92400e", width: 1.5, height: 0.6, depth: 0.5 },
  fountain:     { label: "Çeşme",        icon: "⛲", color: "#94a3b8", width: 3, height: 2, depth: 3 },
  park:         { label: "Park Alanı",   icon: "🏞️", color: "#22c55e", width: 10, height: 0, depth: 8 },
  flag:         { label: "Bayrak",       icon: "🏁", color: "#ef4444", width: 0.5, height: 5, depth: 0.5 },
  character:    { label: "Karakter",     icon: "🧑‍🦯", color: "#38bdf8", width: 1, height: 2.5, depth: 1 },
};

// Varsayılan şehir verisi — ilk yükleme
export const DEFAULT_MAP: MapElement[] = [
  // ROADS
  { id: "road1", type: "road", label: "Ana Cadde", description: "Doğu-batı ana yol", x: 0, y: 0, z: 0, width: 50, height: 0, depth: 8, color: "#333333" },
  { id: "road2", type: "road", label: "2. Cadde", description: "Güney yol", x: 0, y: 0, z: -20, width: 50, height: 0, depth: 8, color: "#333333" },
  { id: "road3", type: "road", label: "Dikey Yol 1", description: "Birinci dikey cadde", x: -15, y: 0, z: 0, width: 8, height: 0, depth: 50, color: "#333333", roadRotY: Math.PI / 2 },
  { id: "road4", type: "road", label: "Dikey Yol 2", description: "İkinci dikey cadde", x: 15, y: 0, z: 0, width: 8, height: 0, depth: 50, color: "#333333", roadRotY: Math.PI / 2 },

  // CROSSWALKS
  { id: "cw1", type: "crosswalk", label: "Yaya Geçidi 1", description: "Batı kavşağı", x: -15, y: 0.06, z: 0, width: 6, height: 0, depth: 4, color: "#ffffff", interactive: true, taskId: 1 },
  { id: "cw2", type: "crosswalk", label: "Yaya Geçidi 2", description: "Doğu kavşağı", x: 15, y: 0.06, z: 0, width: 6, height: 0, depth: 4, color: "#ffffff", interactive: true },

  // TRAFFIC LIGHTS
  { id: "tl1", type: "trafficLight", label: "Trafik Işığı Batı", description: "Batı kavşağı ışığı", x: -15, y: 0, z: 5, width: 0.6, height: 5, depth: 0.6, color: "#555555", interactive: true, taskId: 2 },
  { id: "tl2", type: "trafficLight", label: "Trafik Işığı Doğu", description: "Doğu kavşağı ışığı", x: 15, y: 0, z: 5, width: 0.6, height: 5, depth: 0.6, color: "#555555", interactive: true },

  // BUILDINGS
  { id: "b1", type: "building", label: "Okul", description: "Okul bölgesi — çocuklar var, yavaş gidin!", x: -25, y: 0, z: -18, width: 5, height: 6, depth: 4, color: "#7c3aed", floors: 2, roofType: "flat", interactive: true, taskId: 3 },
  { id: "b2", type: "building", label: "Kütüphane", description: "Sessiz kütüphane alanı", x: -25, y: 0, z: -10, width: 4, height: 4, depth: 3, color: "#2563eb", floors: 2, roofType: "flat", interactive: true },
  { id: "b3", type: "building", label: "Hastane", description: "Acil çıkış — ambulanslara yol verin!", x: 25, y: 0, z: -20, width: 6, height: 10, depth: 5, color: "#dc2626", floors: 3, roofType: "flat", interactive: true, taskId: 4 },
  { id: "b4", type: "building", label: "Eczane", description: "Eczane — acil durumlarda yardım", x: 25, y: 0, z: -10, width: 3, height: 3, depth: 2.5, color: "#059669", floors: 1, roofType: "flat", interactive: true },
  { id: "b5", type: "building", label: "Cami", description: "Cami — avluya dikkatli girin", x: 0, y: 0, z: -22, width: 5, height: 8, depth: 5, color: "#0d9488", floors: 1, roofType: "dome", interactive: true, taskId: 9 },
  { id: "b6", type: "building", label: "AVM", description: "Alışveriş merkezi — kalabalık", x: 28, y: 0, z: 10, width: 5, height: 5, depth: 4, color: "#e11d48", floors: 2, roofType: "flat", interactive: true },
  { id: "b7", type: "building", label: "Market", description: "Market — karşıya geçerken dikkat", x: -25, y: 0, z: 10, width: 4, height: 3, depth: 3, color: "#ea580c", floors: 1, roofType: "flat", interactive: true, taskId: 8 },
  { id: "b8", type: "building", label: "Kafe", description: "Kafe — sakin alan", x: 0, y: 0, z: 12, width: 3, height: 2.5, depth: 2.5, color: "#b45309", floors: 1, roofType: "flat", interactive: true },
  { id: "b9", type: "building", label: "Ev 1", description: "Konut — sessiz olun", x: 28, y: 0, z: 18, width: 3.5, height: 3, depth: 3, color: "#d97706", floors: 1, roofType: "pointed", interactive: true },
  { id: "b10", type: "building", label: "Ev 2", description: "Konut bölgesi", x: 28, y: 0, z: 26, width: 3, height: 2.8, depth: 2.8, color: "#9333ea", floors: 1, roofType: "pointed", interactive: true },
  { id: "b11", type: "building", label: "Ev 3", description: "Konut bölgesi", x: 34, y: 0, z: 22, width: 3.5, height: 3.2, depth: 3, color: "#0891b2", floors: 1, roofType: "pointed", interactive: true },

  // PARK
  { id: "park1", type: "park", label: "Şehir Parkı", description: "Dinlenme alanı", x: 0, y: 0.03, z: 22, width: 10, height: 0, depth: 8, color: "#22c55e" },

  // TREES
  { id: "t1", type: "tree", label: "Ağaç 1", description: "Ağaç", x: -18, y: 0, z: -5, width: 1, height: 4, depth: 1, color: "#22c55e", scale: 1.2 },
  { id: "t2", type: "tree", label: "Ağaç 2", description: "Ağaç", x: -18, y: 0, z: 5, width: 1, height: 4, depth: 1, color: "#22c55e", scale: 1 },
  { id: "t3", type: "tree", label: "Ağaç 3", description: "Ağaç", x: -8, y: 0, z: -8, width: 1, height: 4, depth: 1, color: "#16a34a", scale: 1.1 },
  { id: "t4", type: "tree", label: "Ağaç 4", description: "Ağaç", x: 8, y: 0, z: -12, width: 1, height: 4, depth: 1, color: "#22c55e", scale: 1 },
  { id: "t5", type: "tree", label: "Ağaç 5", description: "Park ağacı", x: -3, y: 0, z: 20, width: 1, height: 4, depth: 1, color: "#15803d", scale: 1.3 },
  { id: "t6", type: "tree", label: "Ağaç 6", description: "Park ağacı", x: 3, y: 0, z: 24, width: 1, height: 4, depth: 1, color: "#22c55e", scale: 1.1 },
  { id: "t7", type: "tree", label: "Ağaç 7", description: "Park ağacı", x: -3, y: 0, z: 25, width: 1, height: 4, depth: 1, color: "#16a34a", scale: 0.9 },
  { id: "t8", type: "tree", label: "Ağaç 8", description: "Okul ağacı", x: -18, y: 0, z: 15, width: 1, height: 4, depth: 1, color: "#22c55e", scale: 0.9 },

  // STREET LAMPS
  { id: "l1", type: "streetLamp", label: "Lamba 1", description: "Sokak lambası", x: -14, y: 0, z: 3, width: 0.5, height: 4, depth: 0.5, color: "#fbbf24" },
  { id: "l2", type: "streetLamp", label: "Lamba 2", description: "Sokak lambası", x: 14, y: 0, z: 3, width: 0.5, height: 4, depth: 0.5, color: "#fbbf24" },
  { id: "l3", type: "streetLamp", label: "Lamba 3", description: "Sokak lambası", x: -14, y: 0, z: -3, width: 0.5, height: 4, depth: 0.5, color: "#fbbf24" },
  { id: "l4", type: "streetLamp", label: "Lamba 4", description: "Sokak lambası", x: 14, y: 0, z: -3, width: 0.5, height: 4, depth: 0.5, color: "#fbbf24" },
  { id: "l5", type: "streetLamp", label: "Lamba 5", description: "Park lambası", x: -8, y: 0, z: 5, width: 0.5, height: 4, depth: 0.5, color: "#fbbf24" },
  { id: "l6", type: "streetLamp", label: "Lamba 6", description: "Park lambası", x: 8, y: 0, z: 5, width: 0.5, height: 4, depth: 0.5, color: "#fbbf24" },

  // BUS STOP
  { id: "bs1", type: "busStop", label: "Otobüs Durağı", description: "Otobüs gelene kadar bekleyin", x: -20, y: 0, z: 12, width: 2.2, height: 3, depth: 1.2, color: "#6366f1", interactive: true, taskId: 7 },

  // BENCHES
  { id: "bn1", type: "bench", label: "Park Bankı 1", description: "Dinlenme bankı", x: 0, y: 0, z: 19, width: 1.5, height: 0.6, depth: 0.5, color: "#92400e" },
  { id: "bn2", type: "bench", label: "Park Bankı 2", description: "Dinlenme bankı", x: 3, y: 0, z: 24, width: 1.5, height: 0.6, depth: 0.5, color: "#92400e" },

  // FOUNTAIN
  { id: "f1", type: "fountain", label: "Park Çeşmesi", description: "Süs çeşmesi", x: 0, y: 0, z: 22, width: 3, height: 2, depth: 3, color: "#94a3b8" },

  // FLAG
  { id: "fl1", type: "flag", label: "Varış Noktası", description: "Hedef! Tüm görevleri tamamla!", x: 0, y: 0, z: -25, width: 0.5, height: 5, depth: 0.5, color: "#ef4444", interactive: true, taskId: 10 },

  // CARS
  { id: "c1", type: "car", label: "Araba 1", description: "Mavi araba", x: -30, y: 0, z: 1, width: 2, height: 1, depth: 1, color: "#3b82f6", carColor: "#3b82f6", dirX: 1, speed: 3 },
  { id: "c2", type: "car", label: "Araba 2", description: "Kırmızı araba", x: 30, y: 0, z: -1, width: 2, height: 1, depth: 1, color: "#ef4444", carColor: "#ef4444", dirX: -1, speed: 2.5 },
  { id: "c3", type: "car", label: "Araba 3", description: "Yeşil araba", x: -25, y: 0, z: 19, width: 2, height: 1, depth: 1, color: "#22c55e", carColor: "#22c55e", dirX: 1, speed: 2 },

  // CHARACTER
  { id: "char1", type: "character", label: "Sen", description: "Karakter", x: 0, y: 0, z: 25, width: 1, height: 2.5, depth: 1, color: "#38bdf8" },
];

let _nextId = 1000;
export function generateId(): string {
  return `el_${++_nextId}_${Date.now().toString(36)}`;
}

export function hexToNum(hex: string): number {
  return parseInt(hex.replace("#", ""), 16);
}

export function numToHex(n: number): string {
  return "#" + n.toString(16).padStart(6, "0");
}
