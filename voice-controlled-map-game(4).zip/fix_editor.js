const fs = require('fs');
let content = fs.readFileSync('src/components/UE5Editor.tsx', 'utf8');

// Replace top
const oldTop = '          {selectedEl ? (\n            <div className="flex-1 flex flex-col p-3 space-y-4 text-[11px] bg-[#1c1c1c]">';

const newTop = `          {selectedEl ? (
            <div className="flex-1 flex flex-col p-3 space-y-4 text-[11px] bg-[#1c1c1c]">
              {(() => {
                const updateElProp = (key, value) => { onUpdate(elements.map(e => e.id === selectedId ? { ...e, [key]: value } : e)); };
                return (
                  <>`;

content = content.replace(oldTop, newTop);

// Replace bottom
const oldBottom = '              </div>\n\n            </div>\n          ) : (';

const newBottom = `              </div>
                  </>
                );
              })()}
            </div>
          ) : (`;

content = content.replace(oldBottom, newBottom);

// Replace all occurrences of onUpdate(selectedEl.id
content = content.replace(/onUpdate\(selectedEl\.id/g, 'updateElProp');

fs.writeFileSync('src/components/UE5Editor.tsx', content);
console.log('Script completed successfully from file!');
