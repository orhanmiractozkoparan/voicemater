const fs = require('fs');
let c = fs.readFileSync('src/components/GameClient.tsx', 'utf8');

// Replace imports
c = c.replace(
  'const MapEditor = dynamic(() => import("@/components/MapEditor").then(m => ({ default: m.MapEditor })), { ssr: false, loading: () => <LoadBox text="Editör Yükleniyor..." /> });',
  'const UE5Editor = dynamic(() => import("@/components/UE5Editor").then(m => ({ default: m.UE5Editor })), { ssr: false, loading: () => <LoadBox text="Unreal Engine 5 Editör Yükleniyor..." /> });\nconst UE5Viewport = dynamic(() => import("@/components/UE5Viewport"), { ssr: false, loading: () => <LoadBox text="Viewport Yükleniyor..." /> });'
);

// Add states inside GameClient
c = c.replace(
  '  const [selectedMapId, setSelectedMapId] = useState<string | null>(null);',
  '  const [selectedMapId, setSelectedMapId] = useState<string | null>(null);\n  const [transformMode, setTransformMode] = useState<"translate" | "rotate" | "scale">("translate");\n  const [snapEnabled, setSnapEnabled] = useState(true);\n  const [snapValue, setSnapValue] = useState(0.5);'
);

// Replace editor block
const oldEditor = `  // ===== EDITOR =====
  if (screen === "editor") {
    return (
      <MapEditor
        elements={mapElements}
        onUpdate={setMapElements}
        onBack={() => setScreen("welcome")}
        onSpeak={voice.speak}
        onSelectOnMap={setSelectedMapId}
        selectedId={selectedMapId}
      />
    );
  }`;

const newEditor = `  // ===== EDITOR =====
  if (screen === "editor") {
    return (
      <UE5Editor
        elements={mapElements}
        onUpdate={setMapElements}
        onBack={() => setScreen("welcome")}
        onSpeak={voice.speak}
        onPlay={() => { setScreen("map"); setTaskCompleted(false); voice.speak("Play moduna (PIE) geçildi."); }}
        selectedId={selectedMapId}
        onSelectOnMap={setSelectedMapId}
        transformMode={transformMode}
        setTransformMode={setTransformMode}
        snapEnabled={snapEnabled}
        setSnapEnabled={setSnapEnabled}
        snapValue={snapValue}
        setSnapValue={setSnapValue}
      >
        <UE5Viewport
          elements={mapElements}
          selectedId={selectedMapId}
          onSelect={setSelectedMapId}
          transformMode={transformMode}
          onElementUpdate={(id, updates) => {
            if (id === "__mode") { setTransformMode(updates.label); return; }
            setMapElements(elems => elems.map(e => e.id === id ? { ...e, ...updates } : e));
          }}
          playMode={false}
          characterPos={{ x: 0, y: 0, z: 25 }}
          taskCompleted={false}
          onHoverObject={setHoveredObject}
          snapEnabled={snapEnabled}
          snapValue={snapValue}
        />
      </UE5Editor>
    );
  }`;

c = c.replace(oldEditor, newEditor);

fs.writeFileSync('src/components/GameClient.tsx', c);
console.log('Client script completed!');
